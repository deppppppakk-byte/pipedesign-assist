KEYDECK RECEIVER v1.0
=====================

1. Run KeyDeckReceiver.exe on your Windows PC.
2. If Windows Firewall asks, allow it on Private networks only.
3. Open KeyDeck on Android and tap Connect -> Scan QR, or use Discover.
4. For the first connection, enter the six-digit pairing code shown in the receiver window.
5. After pairing, KeyDeck uses authenticated trusted reconnect for that PC.

Ports
-----
UDP 8764  LAN discovery
TCP 8765  authenticated keyboard/mouse control

If discovery is blocked, use the PC's LAN IPv4 address shown in the receiver window.
Do not run another old receiver on ports 8764/8765 at the same time.

Firewall helper
---------------
Run Allow-KeyDeck-Firewall.ps1 as Administrator only if automatic firewall permission did not work.
