module keydeck/receiver

go 1.23
