# KeyDeck v1.0

KeyDeck turns an Android phone/tablet into a low-latency Windows keyboard, precision touchpad and engineering shortcut deck.

- Full landscape desktop-style keyboard
- Compact precision touchpad with tap, drag, two-finger scroll and right-click
- Deck / Pad / Work / Numpad / Media / CAD workspaces
- Multiwork quick switcher and Control Center
- Adjustable keyboard/touchpad split and pointer sensitivity
- Android clipboard-to-PC text send
- QR-assisted pairing, discovery, manual IP fallback
- Per-PC authenticated trust and reconnect
- Standalone Windows GUI receiver (no browser dashboard)
