# KeyDeck Android v1.0

Landscape Android remote keyboard + precision touchpad for KeyDeck Receiver.

Implemented workspaces: Deck, Pad, Work, Numpad, Media, CAD and Multiwork quick switcher.
Connection: QR-assisted LAN discovery, manual IP fallback, protocol v5 authenticated pairing, per-PC trust, remembered PC switching and automatic reconnect.
