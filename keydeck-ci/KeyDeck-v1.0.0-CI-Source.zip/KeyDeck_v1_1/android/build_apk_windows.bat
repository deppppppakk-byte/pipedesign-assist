@echo off
setlocal
where gradlew >nul 2>nul
if exist gradlew.bat (
  call gradlew.bat clean assembleDebug
) else (
  echo Open this folder in Android Studio and choose Build ^> Build APK(s).
  echo Or install Gradle and run: gradle clean assembleDebug
)
endlocal
