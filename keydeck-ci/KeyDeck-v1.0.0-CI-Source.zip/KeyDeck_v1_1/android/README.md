# KeyDeck Android v1.0

Landscape-first Android controller for the KeyDeck Windows Receiver.

Workspaces: Deck, Pad, Work, Numpad, Media, CAD, Multiwork.

Connection methods:
- Live QR from KeyDeck Receiver
- UDP LAN discovery
- Manual PC IP fallback

Pairing is per-PC and trusted reconnect uses HMAC-SHA256.
