//go:build !windows

package main

import (
	"log"
	"time"
)

func runReceiverUI(s *appState, hostName string) {
	log.Printf("KeyDeck Receiver running on UDP %d / TCP %d", udpPort, tcpPort)
	for {
		time.Sleep(time.Hour)
	}
}
