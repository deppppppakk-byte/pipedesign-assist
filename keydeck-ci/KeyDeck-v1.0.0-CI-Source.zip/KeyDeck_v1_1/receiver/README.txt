KeyDeck Receiver v1.0

1. Run KeyDeckReceiver.exe on Windows 10/11.
2. Allow Windows Defender Firewall access on Private networks.
3. Keep the Android phone and PC on the same LAN/Wi-Fi.
4. Open KeyDeck > Connect > Scan QR.
5. The QR contains the current LAN address, TCP port, receiver name, and one-time pairing code.
6. After first pairing, KeyDeck stores a per-PC trusted key and reconnects automatically.

Ports:
- UDP 8764: LAN discovery
- TCP 8765: authenticated keyboard/mouse control

Security:
- Private LAN clients only
- Six-digit first-pairing code
- Per-device random secret
- HMAC-SHA256 challenge on trusted reconnect

Do not run older WirelessKey/KeyDeck receiver builds at the same time because they may use the same ports.
