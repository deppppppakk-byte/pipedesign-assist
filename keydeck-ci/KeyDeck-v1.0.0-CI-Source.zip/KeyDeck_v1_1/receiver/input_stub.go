//go:build !windows

package main

func injectMove(dx, dy int)       {}
func injectClick(button string)   {}
func injectScroll(dy int)         {}
func injectKey(vk int, down bool) {}
func injectText(s string)         {}

func injectMouseButton(button string, down bool) {}
