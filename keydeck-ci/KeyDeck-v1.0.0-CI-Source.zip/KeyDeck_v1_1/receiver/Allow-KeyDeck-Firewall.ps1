$ErrorActionPreference = "Stop"
$rules = @(
  @{Name="KeyDeck Discovery UDP 8764"; Protocol="UDP"; LocalPort="8764"},
  @{Name="KeyDeck Control TCP 8765"; Protocol="TCP"; LocalPort="8765"}
)
foreach ($r in $rules) {
  Get-NetFirewallRule -DisplayName $r.Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule
  New-NetFirewallRule -DisplayName $r.Name -Direction Inbound -Action Allow -Profile Private -Protocol $r.Protocol -LocalPort $r.LocalPort | Out-Null
}
Write-Host "KeyDeck Private-network firewall rules installed."
