# KeyDeck v1.0

KeyDeck turns an Android phone/tablet into a low-latency Windows keyboard, precision touchpad and engineering shortcut deck.

## Android
- Full landscape keyboard with F1-F12, navigation keys, modifiers and inverted-T arrows
- Small precision touchpad beside the keyboard in Deck mode
- Dedicated Pad, Work, Numpad, Media and CAD workspaces
- Multiwork quick popup
- Adjustable keyboard/touchpad split
- Precision / Balanced / Fast pointer modes
- Tap, two-finger right-click, two-finger scroll and long-press drag
- Android clipboard/text sending
- QR, LAN discovery and manual IP connection
- Per-PC trusted pairing and automatic reconnect

## Windows Receiver
- Native standalone Windows GUI; no browser dashboard
- Live one-time pairing code
- Live QR generated from current LAN IP, port, PC name and pairing code
- Trusted-device display and forget control
- UDP discovery + authenticated TCP control
- HMAC-SHA256 trusted reconnect
- Private-LAN-only connection filtering
