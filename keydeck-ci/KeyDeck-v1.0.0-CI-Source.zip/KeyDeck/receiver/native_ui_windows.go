//go:build windows

package main

import (
	"fmt"
	"net/url"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"

	qrcode "github.com/skip2/go-qrcode"
)

var (
	uiUser32 = syscall.NewLazyDLL("user32.dll")
	uiGdi32  = syscall.NewLazyDLL("gdi32.dll")
	uiKernel = syscall.NewLazyDLL("kernel32.dll")

	pRegisterClassExW = uiUser32.NewProc("RegisterClassExW")
	pCreateWindowExW  = uiUser32.NewProc("CreateWindowExW")
	pDefWindowProcW   = uiUser32.NewProc("DefWindowProcW")
	pShowWindow       = uiUser32.NewProc("ShowWindow")
	pUpdateWindow     = uiUser32.NewProc("UpdateWindow")
	pGetMessageW      = uiUser32.NewProc("GetMessageW")
	pTranslateMessage = uiUser32.NewProc("TranslateMessage")
	pDispatchMessageW = uiUser32.NewProc("DispatchMessageW")
	pPostQuitMessage  = uiUser32.NewProc("PostQuitMessage")
	pBeginPaint       = uiUser32.NewProc("BeginPaint")
	pEndPaint         = uiUser32.NewProc("EndPaint")
	pInvalidateRect   = uiUser32.NewProc("InvalidateRect")
	pSetTimer         = uiUser32.NewProc("SetTimer")
	pSetCursor        = uiUser32.NewProc("SetCursor")
	pLoadCursorW      = uiUser32.NewProc("LoadCursorW")

	pCreateSolidBrush = uiGdi32.NewProc("CreateSolidBrush")
	pDeleteObject     = uiGdi32.NewProc("DeleteObject")
	pFillRect         = uiUser32.NewProc("FillRect")
	pRoundRect        = uiGdi32.NewProc("RoundRect")
	pSetTextColor     = uiGdi32.NewProc("SetTextColor")
	pSetBkMode        = uiGdi32.NewProc("SetBkMode")
	pCreateFontW      = uiGdi32.NewProc("CreateFontW")
	pSelectObject     = uiGdi32.NewProc("SelectObject")
	pTextOutW         = uiGdi32.NewProc("TextOutW")
	pRectangle        = uiGdi32.NewProc("Rectangle")

	pGetModuleHandleW = uiKernel.NewProc("GetModuleHandleW")
)

const (
	wmDestroy          = 0x0002
	wmPaint            = 0x000F
	wmTimer            = 0x0113
	wmLButtonUp        = 0x0202
	wmSetCursor        = 0x0020
	wsOverlappedWindow = 0x00CF0000
	swShow             = 5
	colorWindow        = 5
	transparent        = 1
	idcArrow           = 32512
)

type wndClassEx struct {
	Size, Style              uint32
	WndProc                  uintptr
	ClsExtra, WndExtra       int32
	Instance                 uintptr
	Icon, Cursor, Background uintptr
	MenuName, ClassName      *uint16
	IconSm                   uintptr
}

type point struct{ X, Y int32 }
type rect struct{ Left, Top, Right, Bottom int32 }
type paintStruct struct {
	Hdc                uintptr
	Erase              int32
	RcPaint            rect
	Restore, IncUpdate int32
	Reserved           [32]byte
}
type msg struct {
	Hwnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             point
	Private        uint32
}

type clickRect struct{ l, t, r, b int32 }

func (r clickRect) has(x, y int32) bool { return x >= r.l && x <= r.r && y >= r.t && y <= r.b }

var uiState *appState
var uiHostName string
var rotateRect = clickRect{l: 58, t: 512, r: 235, b: 555}
var forgetRect = clickRect{l: 248, t: 512, r: 435, b: 555}

func wptr(s string) *uint16    { p, _ := syscall.UTF16PtrFromString(s); return p }
func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

func brush(color uintptr) uintptr { h, _, _ := pCreateSolidBrush.Call(color); return h }
func fill(hdc uintptr, r rect, color uintptr) {
	b := brush(color)
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&r)), b)
	pDeleteObject.Call(b)
}
func font(size int32, bold bool) uintptr {
	weight := int32(400)
	if bold {
		weight = 700
	}
	h, _, _ := pCreateFontW.Call(uintptr(int32(-size)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(wptr("Segoe UI"))))
	return h
}
func textAt(hdc uintptr, x, y int32, s string, size int32, color uintptr, bold bool) {
	f := font(size, bold)
	old, _, _ := pSelectObject.Call(hdc, f)
	pSetBkMode.Call(hdc, transparent)
	pSetTextColor.Call(hdc, color)
	u, _ := syscall.UTF16FromString(s)
	if len(u) > 0 {
		pTextOutW.Call(hdc, uintptr(x), uintptr(y), uintptr(unsafe.Pointer(&u[0])), uintptr(len(u)-1))
	}
	pSelectObject.Call(hdc, old)
	pDeleteObject.Call(f)
}
func roundBox(hdc uintptr, r rect, color uintptr, radius int32) {
	b := brush(color)
	old, _, _ := pSelectObject.Call(hdc, b)
	pRoundRect.Call(hdc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), uintptr(radius), uintptr(radius))
	pSelectObject.Call(hdc, old)
	pDeleteObject.Call(b)
}

func pairingPayload() string {
	values := url.Values{}
	values.Set("v", strconv.Itoa(protocolVersion))
	values.Set("port", strconv.Itoa(tcpPort))
	values.Set("code", uiState.currentCode())
	values.Set("name", uiHostName)
	ips := localIPv4s()
	if len(ips) > 0 {
		values.Set("host", ips[0])
	}
	u := url.URL{Scheme: "keydeck", Host: "pair", RawQuery: values.Encode()}
	return u.String()
}

func drawQR(hdc uintptr, x, y, size int32) {
	qr, err := qrcode.New(pairingPayload(), qrcode.Medium)
	if err != nil {
		fill(hdc, rect{x, y, x + size, y + size}, rgb(255, 255, 255))
		textAt(hdc, x+18, y+105, "QR unavailable", 12, rgb(120, 0, 0), true)
		return
	}
	bitmap := qr.Bitmap()
	n := len(bitmap)
	if n == 0 {
		return
	}
	fill(hdc, rect{x, y, x + size, y + size}, rgb(255, 255, 255))
	cell := float64(size) / float64(n)
	black := brush(rgb(8, 12, 18))
	defer pDeleteObject.Call(black)
	for row := 0; row < n; row++ {
		for col := 0; col < len(bitmap[row]); col++ {
			if bitmap[row][col] {
				l := x + int32(float64(col)*cell)
				t := y + int32(float64(row)*cell)
				r := x + int32(float64(col+1)*cell) + 1
				b := y + int32(float64(row+1)*cell) + 1
				rr := rect{l, t, r, b}
				pFillRect.Call(hdc, uintptr(unsafe.Pointer(&rr)), black)
			}
		}
	}
}

func paintUI(hwnd, hdc uintptr) {
	fill(hdc, rect{0, 0, 840, 600}, rgb(7, 11, 18))
	textAt(hdc, 42, 28, "KEYDECK", 25, rgb(242, 246, 251), true)
	textAt(hdc, 173, 35, "RECEIVER  •  v1.0", 12, rgb(92, 214, 255), true)

	uiState.mu.RLock()
	connected := make([]string, 0, len(uiState.Connected))
	for _, n := range uiState.Connected {
		connected = append(connected, n)
	}
	trusted := make([]trustedDevice, 0, len(uiState.Trusted))
	for _, d := range uiState.Trusted {
		trusted = append(trusted, d)
	}
	uiState.mu.RUnlock()
	status := "Ready for KeyDeck"
	statusColor := rgb(135, 153, 173)
	if len(connected) > 0 {
		status = "Connected • " + strings.Join(connected, ", ")
		statusColor = rgb(113, 230, 181)
	}
	textAt(hdc, 566, 35, status, 12, statusColor, true)

	roundBox(hdc, rect{38, 78, 480, 570}, rgb(13, 17, 26), 18)
	textAt(hdc, 58, 98, "PAIR THIS PC", 11, rgb(135, 153, 173), true)
	textAt(hdc, 58, 126, uiState.currentCode(), 45, rgb(242, 246, 251), true)
	textAt(hdc, 58, 181, "Scan this QR from KeyDeck to find this PC on your LAN.", 11, rgb(135, 153, 173), false)
	textAt(hdc, 58, 201, "Then enter the six-digit code shown above to trust it once.", 11, rgb(135, 153, 173), false)
	drawQR(hdc, 58, 232, 245)
	ips := localIPv4s()
	ipLine := "No private LAN address detected"
	if len(ips) > 0 {
		ipLine = "LAN  " + strings.Join(ips, "  •  ")
	}
	textAt(hdc, 320, 250, ipLine, 11, rgb(190, 210, 231), true)
	textAt(hdc, 320, 276, fmt.Sprintf("UDP %d  •  TCP %d  •  Protocol v%d", udpPort, tcpPort, protocolVersion), 11, rgb(135, 153, 173), false)
	textAt(hdc, 320, 318, "1  Keep phone + PC on same Wi-Fi", 11, rgb(190, 210, 231), false)
	textAt(hdc, 320, 346, "2  Scan QR or use Discover PC", 11, rgb(190, 210, 231), false)
	textAt(hdc, 320, 374, "3  Pair once, then trusted reconnect is automatic", 11, rgb(190, 210, 231), false)

	roundBox(hdc, rect{rotateRect.l, rotateRect.t, rotateRect.r, rotateRect.b}, rgb(92, 214, 255), 12)
	textAt(hdc, 78, 525, "New pairing code", 11, rgb(5, 32, 43), true)
	roundBox(hdc, rect{forgetRect.l, forgetRect.t, forgetRect.r, forgetRect.b}, rgb(26, 34, 48), 12)
	textAt(hdc, 270, 525, "Forget devices", 11, rgb(242, 246, 251), true)

	roundBox(hdc, rect{500, 78, 802, 570}, rgb(13, 17, 26), 18)
	textAt(hdc, 522, 98, "CONNECTION", 11, rgb(135, 153, 173), true)
	connLine := "Waiting for Android"
	if len(connected) > 0 {
		connLine = "Secure session active"
	}
	textAt(hdc, 522, 128, connLine, 19, func() uintptr {
		if len(connected) > 0 {
			return rgb(113, 230, 181)
		}
		return rgb(242, 246, 251)
	}(), true)
	textAt(hdc, 522, 170, "TRUSTED DEVICES", 11, rgb(135, 153, 173), true)
	y := 200
	if len(trusted) == 0 {
		textAt(hdc, 522, int32(y), "None yet", 12, rgb(135, 153, 173), false)
	} else {
		for i, d := range trusted {
			if i >= 7 {
				break
			}
			textAt(hdc, 522, int32(y), d.Name, 12, rgb(242, 246, 251), true)
			textAt(hdc, 522, int32(y+22), d.ID, 10, rgb(135, 153, 173), false)
			y += 58
		}
	}
	textAt(hdc, 522, 525, "Private LAN only • authenticated pairing", 10, rgb(135, 153, 173), false)
}

func wndProc(hwnd uintptr, m uint32, wParam, lParam uintptr) uintptr {
	switch m {
	case wmPaint:
		var ps paintStruct
		hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		paintUI(hwnd, hdc)
		pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case wmTimer:
		pInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case wmLButtonUp:
		x := int32(int16(lParam & 0xffff))
		y := int32(int16((lParam >> 16) & 0xffff))
		if rotateRect.has(x, y) {
			uiState.rotateCode()
			pInvalidateRect.Call(hwnd, 0, 0)
			return 0
		}
		if forgetRect.has(x, y) {
			uiState.mu.Lock()
			uiState.Trusted = map[string]trustedDevice{}
			uiState.mu.Unlock()
			uiState.save()
			pInvalidateRect.Call(hwnd, 0, 0)
			return 0
		}
	case wmSetCursor:
		c, _, _ := pLoadCursorW.Call(0, idcArrow)
		pSetCursor.Call(c)
		return 1
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(m), wParam, lParam)
	return r
}

func runReceiverUI(s *appState, hostName string) {
	uiState = s
	uiHostName = hostName
	inst, _, _ := pGetModuleHandleW.Call(0)
	class := wptr("KeyDeckReceiverWindow")
	title := wptr("KeyDeck Receiver")
	cursor, _, _ := pLoadCursorW.Call(0, idcArrow)
	wc := wndClassEx{Size: uint32(unsafe.Sizeof(wndClassEx{})), WndProc: syscall.NewCallback(wndProc), Instance: inst, Cursor: cursor, Background: uintptr(colorWindow + 1), ClassName: class}
	if a, _, _ := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); a == 0 {
		panic("RegisterClassExW failed")
	}
	hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(class)), uintptr(unsafe.Pointer(title)), wsOverlappedWindow, 100, 80, 840, 620, 0, 0, inst, 0)
	if hwnd == 0 {
		panic("CreateWindowExW failed")
	}
	pShowWindow.Call(hwnd, swShow)
	pUpdateWindow.Call(hwnd)
	pSetTimer.Call(hwnd, 1, 1000, 0)
	var m msg
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	time.Sleep(40 * time.Millisecond)
}
