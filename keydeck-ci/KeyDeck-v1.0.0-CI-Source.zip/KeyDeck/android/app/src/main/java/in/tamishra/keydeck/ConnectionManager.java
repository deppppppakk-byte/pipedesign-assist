package in.tamishra.keydeck;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.util.Base64;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class ConnectionManager {
    public interface Listener {
        void onState(String state, String detail);
        void onDiscovered(String name, String host, int port);
        void onPairCodeRequired();
        void onReady(String name, String host);
        void onError(String message);
    }

    public static final int PROTOCOL = 5;
    public static final int UDP_PORT = 8764;
    public static final int TCP_PORT = 8765;

    private final Context context;
    private final Listener listener;
    private final SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService tx = Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final Object sendLock = new Object();

    private volatile Socket socket;
    private volatile BufferedReader reader;
    private volatile BufferedWriter writer;
    private volatile String foundHost;
    private volatile String foundName = "Windows PC";
    private volatile int foundPort = TCP_PORT;
    private volatile String pendingPairCode = "";
    private volatile boolean ready;
    private volatile boolean closed;
    private volatile long lastPongMs;
    private volatile boolean userDisconnect;
    private volatile int reconnectAttempt;
    private volatile long heartbeatGeneration;

    public ConnectionManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        this.prefs = this.context.getSharedPreferences("keydeck_v5", Context.MODE_PRIVATE);
        this.foundHost = prefs.getString("last_host", "");
        this.foundName = prefs.getString("last_name", "Windows PC");
        this.foundPort = prefs.getInt("last_port", TCP_PORT);
    }

    public boolean isReady() { return ready; }
    public String currentHost() { return foundHost == null ? "" : foundHost; }
    public String currentName() { return foundName == null ? "Windows PC" : foundName; }
    public String lastHost() { return prefs.getString("last_host", ""); }
    public int currentPort() { return foundPort; }
    public void setPairCode(String code) { pendingPairCode = code == null ? "" : code.trim(); }

    private String hostKey(String host) {
        if (host == null) host = "";
        return host.replaceAll("[^A-Za-z0-9]", "_");
    }
    private String idKey(String host) { return "trust_" + hostKey(host) + "_id"; }
    private String secretKey(String host) { return "trust_" + hostKey(host) + "_secret"; }
    private String nameKey(String host) { return "trust_" + hostKey(host) + "_name"; }
    private String portKey(String host) { return "trust_" + hostKey(host) + "_port"; }

    public boolean hasTrust() { return hasTrustFor(foundHost); }
    public boolean hasTrustFor(String host) {
        if (host == null || host.trim().isEmpty()) return false;
        return !prefs.getString(idKey(host), "").isEmpty() && !prefs.getString(secretKey(host), "").isEmpty();
    }

    public List<String> knownHosts() {
        Set<String> set = prefs.getStringSet("known_hosts", Collections.emptySet());
        List<String> list = new ArrayList<>(set == null ? Collections.emptySet() : set);
        Collections.sort(list);
        return list;
    }

    public String knownName(String host) {
        String name = prefs.getString(nameKey(host), "");
        return name.isEmpty() ? host : name;
    }

    private void rememberHost(String host, String name, int port) {
        if (host == null || host.trim().isEmpty()) return;
        Set<String> current = prefs.getStringSet("known_hosts", Collections.emptySet());
        Set<String> copy = new HashSet<>(current == null ? Collections.emptySet() : current);
        copy.add(host);
        prefs.edit()
                .putStringSet("known_hosts", copy)
                .putString("last_host", host)
                .putString("last_name", name == null ? "Windows PC" : name)
                .putInt("last_port", port)
                .putString(nameKey(host), name == null ? "Windows PC" : name)
                .putInt(portKey(host), port)
                .apply();
    }

    public void selectKnownHost(String host) {
        if (host == null || host.trim().isEmpty()) return;
        foundHost = host.trim();
        foundName = knownName(foundHost);
        foundPort = prefs.getInt(portKey(foundHost), TCP_PORT);
        rememberHost(foundHost, foundName, foundPort);
    }

    public void discover() {
        if (closed) return;
        userDisconnect = false;
        listener.onState("discovering", "Searching for KeyDeck Receiver…");
        io.execute(() -> {
            WifiManager.MulticastLock lock = null;
            try (DatagramSocket ds = new DatagramSocket()) {
                WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    lock = wm.createMulticastLock("KeyDeckDiscovery");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                }
                ds.setBroadcast(true);
                ds.setSoTimeout(3500);
                byte[] request = "WK5_DISCOVER".getBytes(StandardCharsets.UTF_8);
                DatagramPacket packet = new DatagramPacket(request, request.length,
                        InetAddress.getByName("255.255.255.255"), UDP_PORT);
                ds.send(packet);

                byte[] buf = new byte[2048];
                DatagramPacket response = new DatagramPacket(buf, buf.length);
                ds.receive(response);
                JSONObject offer = new JSONObject(new String(response.getData(), 0, response.getLength(), StandardCharsets.UTF_8));
                if (offer.optInt("proto", -1) != PROTOCOL) {
                    throw new IllegalStateException("Receiver protocol mismatch. Use KeyDeck Receiver.");
                }
                foundHost = response.getAddress().getHostAddress();
                foundName = offer.optString("name", "Windows PC");
                foundPort = offer.optInt("tcp", TCP_PORT);
                rememberHost(foundHost, foundName, foundPort);
                listener.onDiscovered(foundName, foundHost, foundPort);
            } catch (Exception e) {
                String last = prefs.getString("last_host", "");
                if (!last.isEmpty()) {
                    foundHost = last;
                    foundName = prefs.getString("last_name", "Last paired PC");
                    foundPort = prefs.getInt("last_port", TCP_PORT);
                    listener.onDiscovered(foundName, foundHost, foundPort);
                } else {
                    listener.onError("Receiver not found. Keep phone and PC on the same Wi-Fi, allow Private-network firewall access, or enter the PC IP manually.");
                }
            } finally {
                if (lock != null && lock.isHeld()) lock.release();
            }
        });
    }

    public void connectFromQr(String host, int port, String pairCode, String name) {
        if (host == null || host.trim().isEmpty()) {
            listener.onError("The receiver QR does not contain a valid PC address.");
            return;
        }
        foundHost = host.trim();
        foundPort = port > 0 ? port : TCP_PORT;
        foundName = (name == null || name.trim().isEmpty()) ? "Windows PC" : name.trim();
        pendingPairCode = pairCode == null ? "" : pairCode.trim();
        rememberHost(foundHost, foundName, foundPort);
        connect();
    }

    public void connectManual(String host, String pairCode) {
        if (host != null && !host.trim().isEmpty()) {
            foundHost = host.trim();
            foundPort = TCP_PORT;
            foundName = knownName(foundHost);
            rememberHost(foundHost, foundName, foundPort);
        }
        pendingPairCode = pairCode == null ? "" : pairCode.trim();
        connect();
    }

    public void connect() {
        if (closed) return;
        final String host = foundHost;
        final int port = foundPort;
        if (host == null || host.isEmpty()) {
            listener.onError("Discover a PC first, scan its QR, or enter its IP address.");
            return;
        }
        userDisconnect = false;
        listener.onState("connecting", "Connecting to " + foundName + "…");
        io.execute(() -> connectBlocking(host, port));
    }

    private void connectBlocking(String host, int port) {
        closeSocketOnly();
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, port), 4500);
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            s.setSoTimeout(12000);
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8), 32768);
            BufferedWriter w = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), 32768);
            socket = s;
            reader = r;
            writer = w;

            String id = prefs.getString(idKey(host), "");
            JSONObject hello = new JSONObject();
            hello.put("t", "hello");
            hello.put("proto", PROTOCOL);
            hello.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            hello.put("id", id);
            writeNow(hello);

            JSONObject first = readJson(r);
            String type = first.optString("t");
            if ("challenge".equals(type)) {
                String secret = prefs.getString(secretKey(host), "");
                if (secret.isEmpty()) {
                    forgetTrustFor(host);
                    throw new IllegalStateException("Trusted key missing for this PC. Pair again.");
                }
                JSONObject auth = new JSONObject();
                auth.put("t", "auth");
                auth.put("proof", hmac(secret, first.getString("nonce")));
                writeNow(auth);
                JSONObject result = readJson(r);
                if ("error".equals(result.optString("t"))) {
                    forgetTrustFor(host);
                    throw new IllegalStateException("Saved pairing expired on this PC. Pair once again.");
                }
                if (!"ready".equals(result.optString("t"))) throw new IllegalStateException("Unexpected receiver response.");
            } else if ("pair_required".equals(type)) {
                if (pendingPairCode.length() != 6) {
                    closeSocketOnly();
                    listener.onPairCodeRequired();
                    return;
                }
                JSONObject pair = new JSONObject();
                pair.put("t", "pair");
                pair.put("code", pendingPairCode);
                writeNow(pair);
                JSONObject paired = readJson(r);
                if ("error".equals(paired.optString("t"))) {
                    throw new IllegalStateException("Pairing code rejected. Check the current 6-digit code on the PC.");
                }
                if (!"paired".equals(paired.optString("t"))) throw new IllegalStateException("Pairing failed.");
                prefs.edit()
                        .putString(idKey(host), paired.getString("id"))
                        .putString(secretKey(host), paired.getString("secret"))
                        .putString(nameKey(host), foundName)
                        .apply();
                rememberHost(host, foundName, port);
                JSONObject readyMsg = readJson(r);
                if (!"ready".equals(readyMsg.optString("t"))) throw new IllegalStateException("Receiver did not enter ready state.");
                pendingPairCode = "";
            } else if ("error".equals(type)) {
                String code = first.optString("code", "Receiver error");
                if ("protocol_mismatch".equals(code)) throw new IllegalStateException("Receiver version mismatch. Use KeyDeck Receiver.");
                throw new IllegalStateException(code);
            } else {
                throw new IllegalStateException("Unknown receiver response.");
            }

            s.setSoTimeout(0);
            ready = true;
            reconnectAttempt = 0;
            lastPongMs = System.currentTimeMillis();
            rememberHost(host, foundName, port);
            listener.onReady(foundName, host);
            startHeartbeat();
            readLoop(r);
        } catch (Exception e) {
            boolean shouldReconnect = !userDisconnect && !closed && hasTrustFor(host);
            ready = false;
            closeSocketOnly();
            listener.onError(e.getMessage() == null ? "Connection failed." : e.getMessage());
            if (shouldReconnect) scheduleReconnect();
        }
    }

    private JSONObject readJson(BufferedReader r) throws Exception {
        String line = r.readLine();
        if (line == null) throw new IllegalStateException("Receiver closed the connection.");
        if (line.length() > 32768) throw new IllegalStateException("Receiver response too large.");
        return new JSONObject(line);
    }

    private String hmac(String secretB64, String nonce) throws Exception {
        byte[] secret = Base64.decode(secretB64, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret, "HmacSHA256"));
        return Base64.encodeToString(mac.doFinal(nonce.getBytes(StandardCharsets.UTF_8)), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    private void readLoop(BufferedReader r) throws Exception {
        while (!closed && ready) {
            String line = r.readLine();
            if (line == null) throw new IllegalStateException("Receiver disconnected.");
            JSONObject msg = new JSONObject(line);
            if ("pong".equals(msg.optString("t"))) lastPongMs = System.currentTimeMillis();
        }
    }

    private void startHeartbeat() {
        final long generation = ++heartbeatGeneration;
        scheduler.schedule(() -> heartbeatTick(generation), 3, TimeUnit.SECONDS);
    }

    private void heartbeatTick(long generation) {
        if (closed || !ready || generation != heartbeatGeneration) return;
        long age = System.currentTimeMillis() - lastPongMs;
        if (age > 16000) {
            ready = false;
            ++heartbeatGeneration;
            closeSocketOnly();
            listener.onState("disconnected", "Receiver heartbeat timed out. Reconnecting…");
            if (!userDisconnect && hasTrust()) scheduleReconnect();
            return;
        }
        send(simple("ping"));
        scheduler.schedule(() -> heartbeatTick(generation), 5, TimeUnit.SECONDS);
    }

    private void scheduleReconnect() {
        if (closed || userDisconnect || ready) return;
        reconnectAttempt = Math.min(reconnectAttempt + 1, 6);
        long delay = Math.min(12, 1L << Math.min(reconnectAttempt - 1, 3));
        listener.onState("connecting", "Reconnecting in " + delay + "s…");
        scheduler.schedule(() -> {
            if (!closed && !userDisconnect && !ready) connect();
        }, delay, TimeUnit.SECONDS);
    }

    private JSONObject simple(String t) {
        JSONObject o = new JSONObject();
        try { o.put("t", t); } catch (Exception ignored) {}
        return o;
    }

    private void writeNow(JSONObject o) throws Exception {
        synchronized (sendLock) {
            if (writer == null) throw new IllegalStateException("Not connected");
            writer.write(o.toString());
            writer.write('\n');
            writer.flush();
        }
    }

    public void send(JSONObject o) {
        if (!ready) return;
        final String payload = o.toString();
        tx.execute(() -> {
            if (!ready) return;
            try {
                synchronized (sendLock) {
                    if (writer == null) return;
                    writer.write(payload);
                    writer.write('\n');
                    writer.flush();
                }
            } catch (Exception e) {
                boolean wasReady = ready;
                ready = false;
                closeSocketOnly();
                if (wasReady) {
                    listener.onState("disconnected", "Connection interrupted. Reconnecting…");
                    if (!userDisconnect && hasTrust()) scheduleReconnect();
                }
            }
        });
    }

    public void sendMove(int dx, int dy) { try { JSONObject o = new JSONObject(); o.put("t", "move"); o.put("dx", dx); o.put("dy", dy); send(o); } catch (Exception ignored) {} }
    public void click(String button) { try { JSONObject o = new JSONObject(); o.put("t", "click"); o.put("button", button); send(o); } catch (Exception ignored) {} }
    public void mouseButton(String button, boolean down) { try { JSONObject o = new JSONObject(); o.put("t", "mouse"); o.put("button", button); o.put("down", down); send(o); } catch (Exception ignored) {} }
    public void scroll(int dy) { try { JSONObject o = new JSONObject(); o.put("t", "scroll"); o.put("dy", dy); send(o); } catch (Exception ignored) {} }
    public void key(int vk, boolean down) { try { JSONObject o = new JSONObject(); o.put("t", "key"); o.put("vk", vk); o.put("down", down); send(o); } catch (Exception ignored) {} }
    public void text(String text) { try { JSONObject o = new JSONObject(); o.put("t", "text"); o.put("text", text); send(o); } catch (Exception ignored) {} }

    public void forgetTrust() { forgetTrustFor(foundHost); }
    public void forgetTrustFor(String host) {
        if (host == null || host.isEmpty()) return;
        prefs.edit().remove(idKey(host)).remove(secretKey(host)).apply();
    }
    public void forgetAllTrust() {
        SharedPreferences.Editor e = prefs.edit();
        for (String host : knownHosts()) {
            e.remove(idKey(host)).remove(secretKey(host)).remove(nameKey(host)).remove(portKey(host));
        }
        e.remove("known_hosts").apply();
    }

    public void disconnect() {
        userDisconnect = true;
        ready = false;
        ++heartbeatGeneration;
        closeSocketOnly();
        listener.onState("disconnected", "Disconnected");
    }

    private void closeSocketOnly() {
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        socket = null;
        reader = null;
        writer = null;
    }

    public void close() {
        closed = true;
        userDisconnect = true;
        ready = false;
        ++heartbeatGeneration;
        closeSocketOnly();
        io.shutdownNow();
        tx.shutdownNow();
        scheduler.shutdownNow();
    }
}
