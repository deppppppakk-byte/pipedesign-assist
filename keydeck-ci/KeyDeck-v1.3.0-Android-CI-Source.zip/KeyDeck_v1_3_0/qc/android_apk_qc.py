from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'android/app/src/main/java/in/tamishra/keydeck/MainActivity.java').read_text()
conn=(root/'android/app/src/main/java/in/tamishra/keydeck/ConnectionManager.java').read_text()
touch=(root/'android/app/src/main/java/in/tamishra/keydeck/TouchpadView.java').read_text()
gradle=(root/'android/app/build.gradle').read_text()
checks={
 'version_1_3_0': "versionCode 10300" in gradle and "versionName '1.3.0'" in gradle,
 'full_104_keyboard': 'new String[]{"Esc","F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","PrtSc","ScrLk","Pause"}' in main and 'buildFullNumpad()' in main,
 'keyboard_render_watchdog': 'verifyDeckKeyboardRender' in main and 'visible==104' in main,
 'pair_code_limit': 'new InputFilter.LengthFilter(6)' in main,
 'fresh_pair_api': 'pairFreshCurrent' in conn and 'forgetTrustFor(foundHost)' in conn,
 'no_stale_discovery_fallback': 'Receiver not found on this LAN.' in conn and 'Last paired PC' not in conn,
 'connection_generation': 'connectionGeneration' in conn and 'generation != connectionGeneration' in conn,
 'clear_last_host': '.remove("last_host")' in conn,
 'dual_broadcast_discovery': 'DhcpInfo' in conn and '255.255.255.255' in conn,
 'touchpad_float_accumulator': 'private float pendingDx,pendingDy;' in touch and 'Math.round(pendingDx)' in touch,
 'touchpad_100hz': 'postDelayed(this,10)' in touch,
 'hardware_canvas_default': 'setLayerType(View.LAYER_TYPE_SOFTWARE' not in touch,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
if failed: raise SystemExit('ANDROID_APK_QC_FAILED='+','.join(failed))
print('ANDROID_APK_QC=PASS checks='+str(len(checks)))
