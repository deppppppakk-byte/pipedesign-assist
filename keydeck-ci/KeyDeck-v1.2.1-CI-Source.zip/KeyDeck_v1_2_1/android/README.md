# KeyDeck Android v1.2.1

Package: `in.tamishra.keydeck`
Version: 1.2.1 (10201)

If an older CI/debug APK refuses to update, uninstall the older KeyDeck APK first, then install v1.2.1. This also clears obsolete Android-side pairing data.
