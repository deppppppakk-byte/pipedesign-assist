# KeyDeck v1.2.1

KeyDeck turns an Android phone/tablet into a full Windows keyboard, precision touchpad and multi-work controller.

## v1.2.1 full-keyboard + reliability build
- Repairs stale trusted-pairing keys instead of rejecting a new pairing code.
- A 6-digit manual pairing code always starts a clean pairing session.
- QR/manual code pairing now forces a fresh authenticated pair in the first handshake, bypassing stale saved trust completely.
- Previous receiver pairing code remains valid briefly after rotation to prevent race-condition rejection. Hotspot/CGNAT LAN ranges are also accepted.
- Discover always opens the pairing step when a new PC is found.
- Full desktop keyboard restored: F1-F12, Print Screen, Scroll Lock, Pause, Insert, Delete, Home, End, Page Up, Page Down, Menu and full arrows.

## Connection
1. Close every older WirelessKey/KeyDeck receiver.
2. Run KeyDeckReceiver-v1.2.1.exe and allow Private-network firewall access.
3. Keep phone and PC on the same LAN/Wi-Fi.
4. In Android KeyDeck choose Connect > Scan QR.
5. Trusted reconnects are automatic after pairing.

Ports: UDP 8764 discovery, TCP 8765 authenticated input.


## Full 104-key Deck

The main Deck now contains the complete standard 104-key Windows layout on one screen: Esc/F1-F12/system keys, full alphanumeric block, distinct left/right Shift/Ctrl/Alt/Windows keys, Menu, 6-key navigation block, inverted-T arrows, and a 17-key numpad with Num Lock, operators, decimal, tall Plus and Enter.


## v1.2.1 display fix
- Fixed zero-height weighted key buttons that could render the full keyboard area blank on real devices.
- Fixed arrow-cluster child heights.
- Replaced cramped three-button pointer mode row with a single readable cycling mode control.
