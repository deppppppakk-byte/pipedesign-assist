KeyDeck Receiver v1.2.1

1. Close older WirelessKey/KeyDeck receiver builds first.
2. Run KeyDeckReceiver-v1.2.1.exe on Windows 10/11.
3. Allow Windows Defender Firewall access on Private networks.
4. Keep the Android phone and PC on the same LAN/Wi-Fi.
5. Open KeyDeck > Connect > Scan QR.
6. The QR contains the current LAN address, TCP port, receiver name and pairing code.
7. v1.2.1 sends the current pairing code in the first handshake, bypasses stale trust deterministically, accepts common hotspot/CGNAT LAN ranges, and keeps the full 104-key desktop keyboard.

Ports:
- UDP 8764: LAN discovery
- TCP 8765: authenticated keyboard/mouse control

Security:
- Private LAN clients only
- Six-digit first-pairing code
- Short grace window for a just-rotated pairing code
- Per-device random secret
- HMAC-SHA256 challenge on trusted reconnect
