package main

import (
	"bufio"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	protocolVersion = 5
	udpPort         = 8764
	tcpPort         = 8765
	webPort         = 8766
)

type helloMsg struct {
	T      string `json:"t"`
	Proto  int    `json:"proto"`
	Device string `json:"device"`
	ID     string `json:"id"`
	Code   string `json:"code,omitempty"`
}

type genericMsg struct {
	T      string `json:"t"`
	Code   string `json:"code,omitempty"`
	Proof  string `json:"proof,omitempty"`
	DX     int    `json:"dx,omitempty"`
	DY     int    `json:"dy,omitempty"`
	Button string `json:"button,omitempty"`
	VK     int    `json:"vk,omitempty"`
	Down   *bool  `json:"down,omitempty"`
	Text   string `json:"text,omitempty"`
}

type trustedDevice struct {
	ID       string    `json:"id"`
	Name     string    `json:"name"`
	Secret   string    `json:"secret"`
	LastSeen time.Time `json:"lastSeen"`
}

type appState struct {
	mu                 sync.RWMutex
	PairCode           string
	PairExpiry         time.Time
	PreviousPairCode   string
	PreviousPairExpiry time.Time
	Trusted            map[string]trustedDevice
	Connected          map[string]string
	StorePath          string
}

func newState() *appState {
	s := &appState{Trusted: map[string]trustedDevice{}, Connected: map[string]string{}}
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = "."
	}
	dir = filepath.Join(dir, "KeyDeck")
	_ = os.MkdirAll(dir, 0700)
	s.StorePath = filepath.Join(dir, "trusted-devices.json")
	s.load()
	s.rotateCode()
	return s
}

func randomBytes(n int) []byte {
	b := make([]byte, n)
	if _, err := io.ReadFull(rand.Reader, b); err != nil {
		panic(err)
	}
	return b
}

func (s *appState) rotateCode() {
	n, _ := rand.Int(rand.Reader, big.NewInt(900000))
	code := 100000 + int(n.Int64())
	now := time.Now()
	s.mu.Lock()
	if s.PairCode != "" {
		s.PreviousPairCode = s.PairCode
		s.PreviousPairExpiry = now.Add(2 * time.Minute)
	}
	s.PairCode = fmt.Sprintf("%06d", code)
	s.PairExpiry = now.Add(10 * time.Minute)
	s.mu.Unlock()
}

func (s *appState) validPairCode(code string) bool {
	code = strings.TrimSpace(code)
	if code == "" {
		return false
	}
	current := s.currentCode()
	s.mu.RLock()
	previous, previousExpiry := s.PreviousPairCode, s.PreviousPairExpiry
	s.mu.RUnlock()
	return code == current || (code == previous && time.Now().Before(previousExpiry))
}

func (s *appState) load() {
	b, err := os.ReadFile(s.StorePath)
	if err != nil {
		return
	}
	var list []trustedDevice
	if json.Unmarshal(b, &list) != nil {
		return
	}
	for _, d := range list {
		s.Trusted[d.ID] = d
	}
}

func (s *appState) save() {
	s.mu.RLock()
	list := make([]trustedDevice, 0, len(s.Trusted))
	for _, d := range s.Trusted {
		list = append(list, d)
	}
	s.mu.RUnlock()
	b, _ := json.MarshalIndent(list, "", "  ")
	_ = os.WriteFile(s.StorePath, b, 0600)
}

func (s *appState) currentCode() string {
	s.mu.RLock()
	code, exp := s.PairCode, s.PairExpiry
	s.mu.RUnlock()
	if time.Now().After(exp) {
		s.rotateCode()
		s.mu.RLock()
		code = s.PairCode
		s.mu.RUnlock()
	}
	return code
}

func isPrivateIP(ip net.IP) bool {
	if ip == nil {
		return false
	}
	if ip.IsLoopback() {
		return true
	}
	v4 := ip.To4()
	if v4 == nil {
		return ip.IsPrivate() || ip.IsLinkLocalUnicast()
	}
	// RFC1918 private LANs, RFC6598 carrier-grade NAT ranges used by some
	// Android/hotspot networks, and IPv4 link-local fallback networks.
	return v4[0] == 10 ||
		(v4[0] == 172 && v4[1] >= 16 && v4[1] <= 31) ||
		(v4[0] == 192 && v4[1] == 168) ||
		(v4[0] == 100 && v4[1] >= 64 && v4[1] <= 127) ||
		(v4[0] == 169 && v4[1] == 254)
}

func localIPv4s() []string {
	var out []string
	ifaces, _ := net.Interfaces()
	for _, in := range ifaces {
		if in.Flags&net.FlagUp == 0 || in.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := in.Addrs()
		for _, a := range addrs {
			ip, _, err := net.ParseCIDR(a.String())
			if err == nil && ip.To4() != nil && isPrivateIP(ip) {
				out = append(out, ip.String())
			}
		}
	}
	return out
}

func primaryLANIPv4() string {
	// Ask the OS routing table which local IPv4 would be used for a normal
	// outbound connection. UDP Dial does not need to send application data.
	c, err := net.Dial("udp4", "1.1.1.1:80")
	if err == nil {
		if ua, ok := c.LocalAddr().(*net.UDPAddr); ok && ua.IP.To4() != nil && isPrivateIP(ua.IP) {
			ip := ua.IP.String()
			_ = c.Close()
			return ip
		}
		_ = c.Close()
	}
	ips := localIPv4s()
	if len(ips) > 0 {
		return ips[0]
	}
	return ""
}

func startUDP(s *appState, hostName string) {
	addr := &net.UDPAddr{IP: net.IPv4zero, Port: udpPort}
	c, err := net.ListenUDP("udp4", addr)
	if err != nil {
		log.Printf("UDP discovery unavailable: %v", err)
		return
	}
	defer c.Close()
	buf := make([]byte, 1024)
	for {
		n, remote, err := c.ReadFromUDP(buf)
		if err != nil {
			continue
		}
		if !isPrivateIP(remote.IP) {
			continue
		}
		msg := strings.TrimSpace(string(buf[:n]))
		if msg != "WK5_DISCOVER" {
			continue
		}
		resp := map[string]any{"t": "offer", "proto": protocolVersion, "name": hostName, "tcp": tcpPort, "web": webPort}
		b, _ := json.Marshal(resp)
		_, _ = c.WriteToUDP(b, remote)
	}
}

func writeJSON(w *bufio.Writer, v any) error {
	b, _ := json.Marshal(v)
	if _, err := w.Write(append(b, '\n')); err != nil {
		return err
	}
	return w.Flush()
}

func verifyHMAC(secretB64, nonce, proofB64 string) bool {
	sec, err := base64.RawURLEncoding.DecodeString(secretB64)
	if err != nil {
		return false
	}
	got, err := base64.RawURLEncoding.DecodeString(proofB64)
	if err != nil {
		return false
	}
	h := hmac.New(sha256.New, sec)
	_, _ = h.Write([]byte(nonce))
	return hmac.Equal(got, h.Sum(nil))
}

func pairDevice(s *appState, hello helloMsg, previousID string) (string, string) {
	deviceID := hex.EncodeToString(randomBytes(8))
	secret := base64.RawURLEncoding.EncodeToString(randomBytes(32))
	td := trustedDevice{ID: deviceID, Name: hello.Device, Secret: secret, LastSeen: time.Now()}
	s.mu.Lock()
	if previousID != "" {
		delete(s.Trusted, previousID)
	}
	s.Trusted[deviceID] = td
	s.mu.Unlock()
	s.save()
	return deviceID, secret
}

func handleTCP(s *appState, conn net.Conn) {
	defer conn.Close()
	remote := conn.RemoteAddr().(*net.TCPAddr)
	if !isPrivateIP(remote.IP) {
		return
	}
	_ = conn.SetDeadline(time.Now().Add(20 * time.Second))
	r := bufio.NewReaderSize(conn, 32*1024)
	w := bufio.NewWriterSize(conn, 32*1024)
	line, err := r.ReadString('\n')
	if err != nil {
		return
	}
	var hello helloMsg
	if json.Unmarshal([]byte(line), &hello) != nil || hello.T != "hello" || hello.Proto != protocolVersion {
		_ = writeJSON(w, map[string]any{"t": "error", "code": "protocol_mismatch", "expected": protocolVersion})
		return
	}
	if strings.TrimSpace(hello.Device) == "" {
		hello.Device = "Android"
	}

	deviceID := strings.TrimSpace(hello.ID)
	pairCode := strings.TrimSpace(hello.Code)
	authenticated := false

	// A code supplied in the hello message explicitly requests a fresh pairing.
	// This bypasses stale saved trust entirely, which makes QR/manual recovery
	// deterministic instead of depending on an auth-fail/reconnect round trip.
	if pairCode != "" {
		if !s.validPairCode(pairCode) {
			_ = writeJSON(w, map[string]any{"t": "error", "code": "bad_pair_code"})
			return
		}
		previousID := deviceID
		deviceID, secret := pairDevice(s, hello, previousID)
		_ = writeJSON(w, map[string]any{"t": "paired", "id": deviceID, "secret": secret})
		authenticated = true
		s.rotateCode()
	} else {
		s.mu.RLock()
		trusted, ok := s.Trusted[deviceID]
		s.mu.RUnlock()
		if ok {
			nonce := base64.RawURLEncoding.EncodeToString(randomBytes(24))
			_ = writeJSON(w, map[string]any{"t": "challenge", "nonce": nonce})
			authLine, err := r.ReadString('\n')
			if err != nil {
				return
			}
			var auth genericMsg
			if json.Unmarshal([]byte(authLine), &auth) == nil && auth.T == "auth" && verifyHMAC(trusted.Secret, nonce, auth.Proof) {
				authenticated = true
			} else {
				_ = writeJSON(w, map[string]any{"t": "error", "code": "auth_failed"})
				return
			}
		} else {
			_ = writeJSON(w, map[string]any{"t": "pair_required"})
			pairLine, err := r.ReadString('\n')
			if err != nil {
				return
			}
			var pair genericMsg
			if json.Unmarshal([]byte(pairLine), &pair) != nil || pair.T != "pair" || !s.validPairCode(pair.Code) {
				_ = writeJSON(w, map[string]any{"t": "error", "code": "bad_pair_code"})
				return
			}
			deviceID, secret := pairDevice(s, hello, "")
			_ = writeJSON(w, map[string]any{"t": "paired", "id": deviceID, "secret": secret})
			authenticated = true
			s.rotateCode()
		}
	}
	if !authenticated {
		return
	}
	s.mu.Lock()
	s.Connected[deviceID] = hello.Device
	s.mu.Unlock()
	defer func() { s.mu.Lock(); delete(s.Connected, deviceID); s.mu.Unlock() }()
	_ = conn.SetDeadline(time.Time{})
	_ = writeJSON(w, map[string]any{"t": "ready", "proto": protocolVersion})

	for {
		line, err := r.ReadString('\n')
		if err != nil {
			return
		}
		if len(line) > 32768 {
			return
		}
		var m genericMsg
		if json.Unmarshal([]byte(line), &m) != nil {
			continue
		}
		switch m.T {
		case "ping":
			_ = writeJSON(w, map[string]any{"t": "pong", "ts": time.Now().UnixMilli()})
		case "move":
			injectMove(m.DX, m.DY)
		case "click":
			injectClick(m.Button)
		case "mouse":
			if m.Down != nil {
				injectMouseButton(m.Button, *m.Down)
			}
		case "scroll":
			injectScroll(m.DY)
		case "key":
			if m.Down != nil {
				injectKey(m.VK, *m.Down)
			}
		case "text":
			injectText(m.Text)
		}
	}
}

func startTCP(s *appState) error {
	ln, err := net.Listen("tcp4", ":"+strconv.Itoa(tcpPort))
	if err != nil {
		return err
	}
	log.Printf("Control server listening on %s", ln.Addr())
	for {
		c, err := ln.Accept()
		if err == nil {
			go handleTCP(s, c)
		}
	}
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)
	s := newState()
	name, _ := os.Hostname()
	if name == "" {
		name = "Windows PC"
	}
	go startUDP(s, name)
	go func() {
		if err := startTCP(s); err != nil {
			log.Printf("TCP receiver stopped: %v", err)
		}
	}()
	runReceiverUI(s, name)
}
