package in.tamishra.keydeck;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity implements ConnectionManager.Listener {
    private static final int BG=0xFF070A0F, DECK=0xFF0C1118, CARD=0xFF111821, SURFACE=0xFF141C27,
            KEY=0xFF1A2330, KEY2=0xFF222D3B, KEY_PRESSED=0xFF2C394A, BORDER=0xFF2A3645,
            BORDER_SOFT=0xFF202B38, ACCENT=0xFF67D7FF, ACCENT_DARK=0xFF143647, TEXT=0xFFF3F7FB,
            MUTED=0xFF8A9AAD, GOOD=0xFF72E5B5, BAD=0xFFFF8E9D, ACTIVE=0xFF17394B;

    private ConnectionManager conn;
    private SharedPreferences uiPrefs;
    private LinearLayout contentHost;
    private TextView statusDot, statusText, pcText, modeTitle;
    private String currentMode = "Deck";
    private final Map<Integer, Boolean> stickyModifiers = new HashMap<>();
    private final Map<Integer, Button> modifierButtons = new HashMap<>();
    private final Map<String, Button> modeButtons = new HashMap<>();
    private int touchpadMode = 1;
    private int deckKeyboardPercent = 84;
    private boolean pairAfterDiscovery = false;
    private boolean renderRecoveryAttempted = false;
    private final List<Button> deckKeyboardButtons = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        conn = new ConnectionManager(this, this);
        uiPrefs = getSharedPreferences("keydeck_ui", MODE_PRIVATE);
        touchpadMode = uiPrefs.getInt("touchpad_mode", 1);
        int defaultSplit = getResources().getConfiguration().screenWidthDp < 800 ? 85 : 82;
        deckKeyboardPercent = Math.max(80, Math.min(87, uiPrefs.getInt("deck_split", defaultSplit)));
        currentMode = uiPrefs.getString("workspace", "Deck");
        setContentView(buildShell());
        if (!conn.lastHost().isEmpty() && conn.hasTrust()) {
            statusText.setText("Reconnecting…");
            pcText.setText(conn.lastHost());
            contentHost.postDelayed(() -> conn.connect(), 450);
        }
    }

    private View buildShell() {
        LinearLayout root = col();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(8), dp(12), dp(10));

        root.addView(buildTopBar(), lp(-1, dp(50)));
        root.addView(buildModeBar(), lp(-1, dp(42), 5, 8));

        contentHost = col();
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1f));
        showMode(currentMode);
        return root;
    }

    private View buildTopBar() {
        LinearLayout row = row();

        LinearLayout brandBlock = col();
        TextView brand = text("KEYDECK", 18, TEXT, true);
        brand.setLetterSpacing(.10f);
        TextView sub = text("REMOTE INPUT", 8, MUTED, true);
        sub.setLetterSpacing(.18f);
        brandBlock.addView(brand, lp(-2, dp(27)));
        brandBlock.addView(sub, lp(-2, dp(15)));
        row.addView(brandBlock, new LinearLayout.LayoutParams(0, -1, 1f));

        statusDot = text("●", 11, MUTED, true);
        statusText = text("Not connected", 11, MUTED, true);
        pcText = text("", 9, MUTED, false);
        LinearLayout stat = col();
        stat.setPadding(dp(10), dp(3), dp(10), dp(3));
        stat.setBackground(bg(SURFACE, 12, BORDER_SOFT));
        LinearLayout sr = row();
        sr.addView(statusDot, lp(dp(16), -1));
        sr.addView(statusText, lp(-2, -1));
        stat.addView(sr, lp(-2, dp(21)));
        stat.addView(pcText, lp(-2, dp(15)));
        LinearLayout.LayoutParams stp = lp(-2, dp(42));
        stp.setMargins(dp(8),0,0,0);
        row.addView(stat, stp);

        Button control = smallButton("Control", false);
        LinearLayout.LayoutParams ccp = lp(dp(86), dp(40));
        ccp.setMargins(dp(8),0,0,0);
        row.addView(control, ccp);
        control.setOnClickListener(v -> showControlCenter(control));

        Button connect = smallButton("Connect", true);
        LinearLayout.LayoutParams cp = lp(dp(92), dp(40));
        cp.setMargins(dp(6),0,0,0);
        row.addView(connect, cp);
        connect.setOnClickListener(v -> showConnectionPopup(connect));
        return row;
    }

    private View buildModeBar() {
        LinearLayout outer = row();
        TextView label = text("WORKSPACE", 9, MUTED, true);
        label.setLetterSpacing(.14f);
        outer.addView(label, lp(dp(76), -1));

        HorizontalScrollView sc = new HorizontalScrollView(this);
        sc.setHorizontalScrollBarEnabled(false);
        sc.setFillViewport(true);
        LinearLayout modes = row();
        modeButtons.clear();
        String[] labels = {"Deck","Pad","Work","Numpad","Media","CAD"};
        for (String name : labels) {
            Button b = chip(name);
            modeButtons.put(name,b);
            b.setOnClickListener(v -> showMode(name));
            modes.addView(b, lp(dp(name.equals("Numpad") ? 78 : 66), dp(34), 2, 2));
        }
        Button multi = chip("Multiwork");
        multi.setOnClickListener(v -> showMultiworkPopup(multi));
        modes.addView(multi, lp(dp(94), dp(34), 2, 2));
        sc.addView(modes);
        outer.addView(sc, new LinearLayout.LayoutParams(0,-1,1f));
        updateModeVisuals();
        return outer;
    }

    private void showMode(String mode) {
        currentMode = mode;
        if (uiPrefs != null) uiPrefs.edit().putString("workspace", mode).apply();
        if (modeTitle != null) modeTitle.setText(mode);
        updateModeVisuals();
        if (contentHost == null) return;
        contentHost.removeAllViews();
        View v;
        switch (mode) {
            case "Pad": v = buildPadMode(); break;
            case "Work": v = buildWorkMode(); break;
            case "Numpad": v = buildNumpadMode(); break;
            case "Media": v = buildMediaMode(); break;
            case "CAD": v = buildCadMode(); break;
            default: v = buildDeckMode();
        }
        contentHost.addView(v, new LinearLayout.LayoutParams(-1,-1));
        if ("Deck".equals(mode)) contentHost.post(this::verifyDeckKeyboardRender);
    }

    private View buildDeckMode() {
        LinearLayout wrap = row();
        wrap.setPadding(0,0,0,0);

        LinearLayout keyboard = card(false);
        keyboard.setPadding(dp(7),dp(7),dp(7),dp(7));
        keyboard.setElevation(dp(2));
        keyboard.addView(buildKeyboard(), new LinearLayout.LayoutParams(-1,-1));
        wrap.addView(keyboard, new LinearLayout.LayoutParams(0,-1,deckKeyboardPercent));

        LinearLayout side = card(false);
        side.setPadding(dp(9),dp(8),dp(9),dp(8));
        side.setElevation(dp(2));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0,-1,100-deckKeyboardPercent);
        sp.setMargins(dp(8),0,0,0);
        wrap.addView(side, sp);

        LinearLayout padHead = row();
        TextView padTitle = text("TOUCHPAD",10,TEXT,true);
        padTitle.setLetterSpacing(.10f);
        TextView gesture = text("  tap • scroll • drag",8,MUTED,false);
        padHead.addView(padTitle, lp(-2,-1));
        padHead.addView(gesture, new LinearLayout.LayoutParams(0,-1,1f));
        side.addView(padHead, lp(-1,dp(26)));

        TouchpadView pad = touchpad();
        side.addView(pad, new LinearLayout.LayoutParams(-1,0,1f));

        LinearLayout mouse = row();
        Button left = keyStyleButton("LEFT", false), right = keyStyleButton("RIGHT", false);
        mouse.addView(left, new LinearLayout.LayoutParams(0,dp(38),1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0,dp(38),1); rp.setMargins(dp(5),0,0,0);
        mouse.addView(right, rp);
        left.setOnClickListener(v->conn.click("left")); right.setOnClickListener(v->conn.click("right"));
        side.addView(mouse, lp(-1,dp(42),5,0));
        side.addView(buildPadSpeedRow(pad), lp(-1,dp(38),4,0));
        return wrap;
    }

    private View buildKeyboard() {
        deckKeyboardButtons.clear();
        LinearLayout full = col();

        // Standard 104-key PC keyboard: 16-key function/system row.
        addKeyRow(full,
                new String[]{"Esc","F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","PrtSc","ScrLk","Pause"},
                new float[]{1.12f,1,1,1,1,1,1,1,1,1,1,1,1,1.12f,1.12f,1.12f});

        LinearLayout body = row();

        // 61-key alphanumeric block.
        LinearLayout main = col();
        addKeyRow(main, new String[]{"`","1","2","3","4","5","6","7","8","9","0","-","=","Backspace"},
                new float[]{1,1,1,1,1,1,1,1,1,1,1,1,1,1.95f});
        addKeyRow(main, new String[]{"Tab","Q","W","E","R","T","Y","U","I","O","P","[","]","\\"},
                new float[]{1.45f,1,1,1,1,1,1,1,1,1,1,1,1,1.05f});
        addKeyRow(main, new String[]{"Caps","A","S","D","F","G","H","J","K","L",";","'","Enter"},
                new float[]{1.7f,1,1,1,1,1,1,1,1,1,1,1,2.15f});
        addKeyRow(main, new String[]{"L Shift","Z","X","C","V","B","N","M",",",".","/","R Shift"},
                new float[]{2.2f,1,1,1,1,1,1,1,1,1,1,2.45f});
        addKeyRow(main, new String[]{"L Ctrl","L Win","L Alt","Space","R Alt","R Win","Menu","R Ctrl"},
                new float[]{1.35f,1.2f,1.2f,5.55f,1.2f,1.2f,1.25f,1.35f});
        body.addView(main, new LinearLayout.LayoutParams(0,-1,14.8f));

        // 10-key navigation + inverted-T arrow cluster.
        LinearLayout nav = buildNavigationCluster();
        LinearLayout.LayoutParams navp = new LinearLayout.LayoutParams(0,-1,3.35f);
        navp.setMargins(dp(5),0,0,0);
        body.addView(nav, navp);

        // 17-key numeric keypad, part of the Deck (not a separate page).
        LinearLayout num = buildFullNumpad();
        LinearLayout.LayoutParams nump = new LinearLayout.LayoutParams(0,-1,4.15f);
        nump.setMargins(dp(5),0,0,0);
        body.addView(num, nump);

        full.addView(body, new LinearLayout.LayoutParams(-1,0,5f));
        return full;
    }

    private LinearLayout buildNavigationCluster() {
        LinearLayout nav = col();
        addKeyRow(nav, new String[]{"Ins","Home","PgUp"}, new float[]{1,1,1});
        addKeyRow(nav, new String[]{"Del","End","PgDn"}, new float[]{1,1,1});

        // Spacer keeps the arrows in the familiar inverted-T position.
        LinearLayout spacer = row();
        nav.addView(spacer, new LinearLayout.LayoutParams(-1,0,1f));

        LinearLayout up = row();
        Button upKey = keyboardButton("↑");
        LinearLayout.LayoutParams blank = new LinearLayout.LayoutParams(0,-1,1f);
        up.addView(new View(this), blank);
        LinearLayout.LayoutParams uk = new LinearLayout.LayoutParams(0,-1,1f); uk.setMargins(dp(2),dp(2),dp(2),dp(2));
        up.addView(upKey, uk);
        up.addView(new View(this), new LinearLayout.LayoutParams(0,-1,1f));
        nav.addView(up, new LinearLayout.LayoutParams(-1,0,1f));
        addKeyRow(nav, new String[]{"←","↓","→"}, new float[]{1,1,1});
        return nav;
    }

    private LinearLayout buildFullNumpad() {
        LinearLayout num = col();
        addKeyRow(num, new String[]{"Num","Num /","Num *","Num -"}, new float[]{1,1,1,1});

        // Rows 7-9 and 4-6 share one tall plus key.
        LinearLayout upper = row();
        LinearLayout digitsUpper = col();
        addKeyRow(digitsUpper, new String[]{"Num 7","Num 8","Num 9"}, new float[]{1,1,1});
        addKeyRow(digitsUpper, new String[]{"Num 4","Num 5","Num 6"}, new float[]{1,1,1});
        upper.addView(digitsUpper, new LinearLayout.LayoutParams(0,-1,3f));
        Button plus = keyboardButton("Num +");
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0,-1,1f); pp.setMargins(dp(2),dp(2),dp(2),dp(2));
        upper.addView(plus, pp);
        num.addView(upper, new LinearLayout.LayoutParams(-1,0,2f));

        // Rows 1-3 and 0/decimal share one tall numpad Enter key.
        LinearLayout lower = row();
        LinearLayout digitsLower = col();
        addKeyRow(digitsLower, new String[]{"Num 1","Num 2","Num 3"}, new float[]{1,1,1});
        addKeyRow(digitsLower, new String[]{"Num 0","Num ."}, new float[]{2,1});
        lower.addView(digitsLower, new LinearLayout.LayoutParams(0,-1,3f));
        Button enter = keyboardButton("Num Enter");
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0,-1,1f); ep.setMargins(dp(2),dp(2),dp(2),dp(2));
        lower.addView(enter, ep);
        num.addView(lower, new LinearLayout.LayoutParams(-1,0,2f));
        return num;
    }

    private void addKeyRow(LinearLayout kb, String[] labels, float[] weights) {
        LinearLayout row = row();
        for (int i=0;i<labels.length;i++) {
            Button b = keyboardButton(labels[i]);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,-1,weights[i]);
            p.setMargins(dp(1),dp(1),dp(1),dp(1));
            row.addView(b,p);
        }
        kb.addView(row,new LinearLayout.LayoutParams(-1,0,1f));
    }

    private Button keyboardButton(String label) {
        Button b = keyStyleButton(label, isModifierLabel(label));
        b.setTag("keydeck_keyboard_key");
        deckKeyboardButtons.add(b);
        int vk = keyVk(label);
        if (isModifierVk(vk)) {
            modifierButtons.put(vk,b);
            b.setOnClickListener(v -> toggleModifier(vk,b));
        } else if (vk != 0) {
            b.setOnTouchListener((v,e)->{
                if (!conn.isReady()) { if (e.getActionMasked()==MotionEvent.ACTION_DOWN) toastShort("Connect to the receiver first"); return true; }
                if (e.getActionMasked()==MotionEvent.ACTION_DOWN) {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    conn.key(vk,true); v.setPressed(true); return true;
                }
                if (e.getActionMasked()==MotionEvent.ACTION_UP || e.getActionMasked()==MotionEvent.ACTION_CANCEL) {
                    conn.key(vk,false); v.setPressed(false); releaseStickyModifiers(); return true;
                }
                return true;
            });
        }
        return b;
    }

    private void toggleModifier(int vk, Button b) {
        if (!conn.isReady()) { toastShort("Connect to the receiver first"); return; }
        boolean on = !Boolean.TRUE.equals(stickyModifiers.get(vk));
        stickyModifiers.put(vk,on);
        conn.key(vk,on);
        setModifierVisual(b,on);
        b.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void releaseStickyModifiers() {
        for (Map.Entry<Integer,Boolean> e : stickyModifiers.entrySet()) {
            if (Boolean.TRUE.equals(e.getValue())) {
                conn.key(e.getKey(),false);
                Button b=modifierButtons.get(e.getKey()); if(b!=null)setModifierVisual(b,false);
            }
        }
        stickyModifiers.clear();
    }

    private void setModifierVisual(Button b, boolean on) {
        b.setBackground(on ? bg(ACTIVE,7,ACCENT) : keyBackground(true));
        b.setTextColor(on ? ACCENT : TEXT);
    }

    private View buildPadMode() {
        LinearLayout card = card(false);
        card.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout title = row(); title.addView(text("Precision touchpad",18,TEXT,true), new LinearLayout.LayoutParams(0,-1,1));
        TextView tip = text("Tap • drag • two-finger scroll",11,MUTED,false); title.addView(tip);
        card.addView(title,lp(-1,dp(36)));
        TouchpadView pad=touchpad(); card.addView(pad,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom=row();
        Button left=keyStyleButton("Left click",false), right=keyStyleButton("Right click",false), middle=keyStyleButton("Middle",false);
        bottom.addView(left,new LinearLayout.LayoutParams(0,dp(46),1));
        bottom.addView(right,new LinearLayout.LayoutParams(0,dp(46),1));
        bottom.addView(middle,new LinearLayout.LayoutParams(0,dp(46),1));
        left.setOnClickListener(v->conn.click("left"));right.setOnClickListener(v->conn.click("right"));middle.setOnClickListener(v->conn.click("middle"));
        card.addView(bottom,lp(-1,dp(50),5,0));
        card.addView(buildPadSpeedRow(pad),lp(-1,dp(42),3,0));
        return card;
    }

    private TouchpadView touchpad(){ TouchpadView p=new TouchpadView(this); p.setConnection(conn); p.setGainMode(touchpadMode); return p; }
    private View buildPadSpeedRow(TouchpadView pad) {
        LinearLayout r=row();
        String[] modes={"Precise","Balanced","Fast"};
        for(int i=0;i<modes.length;i++){
            final int modeIndex=i;
            Button b=chip(modes[i]);
            b.setTextSize(8.5f);
            setSegmentVisual(b, touchpadMode==i);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(32),1f);
            if(i>0)p.setMargins(dp(4),0,0,0);
            r.addView(b,p);
            b.setOnClickListener(v->{
                touchpadMode=modeIndex;
                uiPrefs.edit().putInt("touchpad_mode",touchpadMode).apply();
                pad.setGainMode(touchpadMode);
                for(int n=0;n<r.getChildCount();n++) if(r.getChildAt(n) instanceof Button) setSegmentVisual((Button)r.getChildAt(n), n==touchpadMode);
            });
        }
        return r;
    }

    private View buildWorkMode() {
        LinearLayout root=card(false); root.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(text("Work shortcuts & clipboard",18,TEXT,true),lp(-1,dp(34)));
        LinearLayout send=row(); EditText e=input("Type or paste text to send to PC"); Button sb=smallButton("Send",true);
        send.addView(e,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams bp=lp(dp(82),dp(48));bp.setMargins(dp(6),0,0,0);send.addView(sb,bp);
        sb.setOnClickListener(v->{String s=e.getText().toString();if(!s.isEmpty()&&conn.isReady()){conn.text(s);e.setText("");}}); root.addView(send,lp(-1,dp(52),2,8));
        Button clip=smallButton("Send Android clipboard",false);
        clip.setOnClickListener(v->{if(!conn.isReady()){toastShort("Connect to the receiver first");return;}android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null&&cm.hasPrimaryClip()&&cm.getPrimaryClip()!=null&&cm.getPrimaryClip().getItemCount()>0){CharSequence cs=cm.getPrimaryClip().getItemAt(0).coerceToText(this);if(cs!=null)conn.text(cs.toString());else toastShort("Clipboard is empty");}else toastShort("Clipboard is empty");});
        root.addView(clip,lp(-1,dp(42),0,7));
        String[][] grid={{"Copy","Paste","Cut","Undo","Redo"},{"Save","Select all","Find","Print","Alt+Tab"},{"Desktop","Task View","Enter","Esc","Delete"}};
        int[][][] combos={{{17,67},{17,86},{17,88},{17,90},{17,89}},{{17,83},{17,65},{17,70},{17,80},{18,9}},{{91,68},{91,9},{13},{27},{46}}};
        for(int rr=0;rr<grid.length;rr++){LinearLayout line=row();for(int cc=0;cc<grid[rr].length;cc++){Button b=keyStyleButton(grid[rr][cc],false);int[] c=combos[rr][cc];b.setOnClickListener(v->sendCombo(c));line.addView(b,new LinearLayout.LayoutParams(0,dp(52),1));}root.addView(line,lp(-1,dp(56)));}
        return root;
    }

    private View buildNumpadMode() {
        LinearLayout root=card(false);root.setPadding(dp(10),dp(10),dp(10),dp(10));root.addView(text("Numeric keypad",18,TEXT,true),lp(-1,dp(36)));
        String[][] rows={{"Num","/","*","-"},{"7","8","9","+"},{"4","5","6","+"},{"1","2","3","Enter"},{"0","0",".","Enter"}};
        for(String[] row:rows){LinearLayout line=row();for(String s:row){Button b=keyStyleButton(s,false);int vk=numpadVk(s);b.setOnClickListener(v->tapKey(vk));line.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));}root.addView(line,lp(-1,dp(62)));}
        return root;
    }

    private View buildMediaMode() {
        LinearLayout root=card(false);root.setPadding(dp(12),dp(10),dp(12),dp(10));root.addView(text("Media control",18,TEXT,true),lp(-1,dp(40)));
        String[][] rows={{"⏮ Prev","⏯ Play/Pause","⏭ Next"},{"🔇 Mute","Vol −","Vol +"},{"Stop","Space","Esc"}};
        int[][] vals={{177,179,176},{173,174,175},{178,32,27}};
        for(int r=0;r<rows.length;r++){LinearLayout line=row();for(int c=0;c<rows[r].length;c++){Button b=keyStyleButton(rows[r][c],false);int vk=vals[r][c];b.setOnClickListener(v->tapKey(vk));line.addView(b,new LinearLayout.LayoutParams(0,dp(72),1));}root.addView(line,lp(-1,dp(78)));}
        return root;
    }

    private View buildCadMode() {
        LinearLayout root=card(false);root.setPadding(dp(12),dp(10),dp(12),dp(10));root.addView(text("CAD / engineering quick keys",18,TEXT,true),lp(-1,dp(38)));
        String[][] labels={{"Esc","F3 Snap","F8 Ortho","F10 Polar","Enter"},{"Ctrl+1","Ctrl+S","Ctrl+Z","Ctrl+Y","Delete"},{"Home","←","↑","↓","→"},{"Space","Tab","Shift","Ctrl","Alt"}};
        int[][][] combos={{{27},{114},{119},{121},{13}},{{17,49},{17,83},{17,90},{17,89},{46}},{{36},{37},{38},{40},{39}},{{32},{9},{16},{17},{18}}};
        for(int r=0;r<labels.length;r++){LinearLayout line=row();for(int c=0;c<labels[r].length;c++){Button b=keyStyleButton(labels[r][c],false);int[] combo=combos[r][c];b.setOnClickListener(v->sendCombo(combo));line.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));}root.addView(line,lp(-1,dp(63)));}
        return root;
    }

    private void showMultiworkPopup(View anchor) {
        LinearLayout box=card(true);box.setPadding(dp(10),dp(10),dp(10),dp(10));
        box.addView(text("Multiwork",15,TEXT,true),lp(-1,dp(30)));
        box.addView(text("Jump between tools without leaving the control deck",10,MUTED,false),lp(-1,dp(30)));
        String[] modes={"Deck","Pad","Work","Numpad","Media","CAD"};
        for(int r=0;r<3;r++){LinearLayout line=row();for(int c=0;c<2;c++){String m=modes[r*2+c];Button b=keyStyleButton(m,false);b.setOnClickListener(v->{showMode(m);Object tag=box.getTag();if(tag instanceof PopupWindow)((PopupWindow)tag).dismiss();});line.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));}box.addView(line,lp(-1,dp(46)));}
        LinearLayout quick=row();
        String[] q={"Copy","Paste","Alt+Tab"}; int[][] combos={{17,67},{17,86},{18,9}};
        for(int i=0;i<q.length;i++){Button b=keyStyleButton(q[i],false);int[] combo=combos[i];b.setOnClickListener(v->sendCombo(combo));quick.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));}
        box.addView(quick,lp(-1,dp(46),4,0));
        PopupWindow pop=new PopupWindow(box,dp(300),-2,true);box.setTag(pop);pop.setBackgroundDrawable(bg(CARD,18,BORDER));pop.setElevation(dp(14));pop.showAsDropDown(anchor,-dp(190),dp(4));
    }

    private void showControlCenter(View anchor) {
        LinearLayout box=card(true); box.setPadding(dp(14),dp(12),dp(14),dp(14));
        box.addView(text("KeyDeck Control Center",17,TEXT,true),lp(-1,dp(32)));
        String state = conn.isReady() ? "Connected to "+conn.currentName()+" • "+conn.currentHost() : "Not connected";
        box.addView(text(state,11,conn.isReady()?GOOD:MUTED,false),lp(-1,dp(28)));

        box.addView(text("Deck split",11,MUTED,true),lp(-1,dp(24),4,0));
        SeekBar split=new SeekBar(this); split.setMax(7); split.setProgress(deckKeyboardPercent-80);
        split.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){deckKeyboardPercent=80+p;if(u&&"Deck".equals(currentMode))showMode("Deck");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){uiPrefs.edit().putInt("deck_split",deckKeyboardPercent).apply();}});
        box.addView(split,lp(-1,dp(42)));

        box.addView(text("Remembered PCs",11,MUTED,true),lp(-1,dp(26),2,0));
        java.util.List<String> hosts=conn.knownHosts();
        if(hosts.isEmpty()){box.addView(text("No trusted PCs yet",11,MUTED,false),lp(-1,dp(30)));}
        else for(String h:hosts){Button b=keyStyleButton(conn.knownName(h)+"  •  "+h,false);b.setOnClickListener(v->{conn.selectKnownHost(h);conn.connect();});box.addView(b,lp(-1,dp(40),2,2));}

        LinearLayout actions=row(); Button disconnect=smallButton("Disconnect",false), forget=smallButton("Forget all",false);
        actions.addView(disconnect,new LinearLayout.LayoutParams(0,dp(42),1));actions.addView(forget,new LinearLayout.LayoutParams(0,dp(42),1));
        disconnect.setOnClickListener(v->conn.disconnect());forget.setOnClickListener(v->{conn.forgetAllTrust();toastShort("Trusted PCs cleared");});
        box.addView(actions,lp(-1,dp(46),6,0));
        PopupWindow pop=new PopupWindow(box,dp(360),-2,true);pop.setBackgroundDrawable(bg(CARD,20,BORDER));pop.setElevation(dp(16));pop.showAsDropDown(anchor,-dp(270),dp(4));
    }

    private void showConnectionPopup(View anchor) {
        LinearLayout box=card(true); box.setPadding(dp(14),dp(12),dp(14),dp(14));
        box.addView(text("Connect KeyDeck",17,TEXT,true),lp(-1,dp(34)));
        TextView hint=text("Recommended: scan the QR from KeyDeck Receiver 1.2.2+. Discover never reuses a stale saved IP.",11,MUTED,false);
        box.addView(hint,lp(-1,dp(48)));

        EditText code=input("6-digit code for fresh pairing");
        code.setInputType(InputType.TYPE_CLASS_NUMBER);
        code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        box.addView(code,lp(-1,dp(46),4,4));

        EditText host=input("PC IP address (manual fallback)");
        host.setText(conn.lastHost());
        box.addView(host,lp(-1,dp(46),4,5));

        LinearLayout r1=row();
        Button scan=smallButton("Scan QR",true), discover=smallButton("Find PC",false);
        r1.addView(scan,new LinearLayout.LayoutParams(0,dp(44),1));
        LinearLayout.LayoutParams dp2=new LinearLayout.LayoutParams(0,dp(44),1); dp2.setMargins(dp(6),0,0,0);
        r1.addView(discover,dp2);
        box.addView(r1,lp(-1,dp(48)));

        Button connect=smallButton("Pair / connect using fields",false);
        box.addView(connect,lp(-1,dp(46),4,3));

        if (conn.hasTrust()) {
            Button reconnect=smallButton("Reconnect saved PC",false);
            reconnect.setOnClickListener(v->{conn.connect();popDismiss(v);});
            box.addView(reconnect,lp(-1,dp(42),2,2));
        }

        TextView target=text("Target: "+(conn.currentHost().isEmpty()?"none":conn.currentName()+" • "+conn.currentHost()+":"+conn.currentPort()),10,MUTED,false);
        box.addView(target,lp(-1,dp(30),2,0));
        Button forget=smallButton("Clear saved Android pairing",false);
        box.addView(forget,lp(-1,dp(42),3,0));

        PopupWindow pop=new PopupWindow(box,dp(350),-2,true);
        pop.setBackgroundDrawable(bg(CARD,20,BORDER)); pop.setElevation(dp(16));
        box.setTag(pop);
        scan.setOnClickListener(v->{scanQr();pop.dismiss();});
        discover.setOnClickListener(v->{pairAfterDiscovery=true;conn.discover();pop.dismiss();});
        connect.setOnClickListener(v->{
            String h=host.getText().toString().trim();
            String c=code.getText().toString().trim();
            if(c.length()>0 && c.length()!=6){code.setError("Enter exactly 6 digits");return;}
            conn.connectManual(h,c); pop.dismiss();
        });
        forget.setOnClickListener(v->{conn.forgetAllTrust();toastShort("Android pairing data cleared");});
        pop.showAsDropDown(anchor,-dp(260),dp(4));
    }

    private void popDismiss(View v) {
        View parent=(View)v.getParent();
        while(parent!=null){Object tag=parent.getTag(); if(tag instanceof PopupWindow){((PopupWindow)tag).dismiss(); return;} Object p=parent.getParent(); parent=p instanceof View?(View)p:null;}
    }

    private void scanQr() {
        try {
            GmsBarcodeScannerOptions options=new GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).enableAutoZoom().build();
            GmsBarcodeScanner scanner= GmsBarcodeScanning.getClient(this,options);
            scanner.startScan()
                    .addOnSuccessListener(barcode->{
                        String raw=barcode.getRawValue();
                        if(raw==null){toast("QR has no data.");return;}
                        try{
                            Uri u=Uri.parse(raw);
                            boolean scheme="keydeck".equalsIgnoreCase(u.getScheme()) || "wirelesskey".equalsIgnoreCase(u.getScheme());
                            if(!scheme || !"pair".equalsIgnoreCase(u.getHost()) || !"5".equals(u.getQueryParameter("v"))){toast("That QR is not from KeyDeck Receiver.");return;}
                            String host=u.getQueryParameter("host"); String code=u.getQueryParameter("code"); String name=u.getQueryParameter("name");
                            int port=ConnectionManager.TCP_PORT; try{String p=u.getQueryParameter("port");if(p!=null)port=Integer.parseInt(p);}catch(Exception ignored){}
                            if(host!=null&&!host.trim().isEmpty()){toastShort("KeyDeck receiver recognized");conn.connectFromQr(host,port,code,name);}
                            else {toastShort("KeyDeck receiver recognized • discovering PC");pairAfterDiscovery=true;conn.setPairCode(code);conn.discover();}
                        }catch(Exception ex){toast("KeyDeck QR could not be read. Use Discover or manual IP.");}
                    })
                    .addOnCanceledListener(()->{})
                    .addOnFailureListener(e->toast("QR scanner unavailable. Use Discover or manual PC IP."));
        } catch (Exception e) { toast("QR scanner unavailable. Use Discover or manual PC IP."); }
    }

    private void showPairCodeDialog(String name,String host) {
        EditText code=input("6-digit code");
        code.setInputType(InputType.TYPE_CLASS_NUMBER);
        code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        code.setTextSize(20);
        code.setGravity(Gravity.CENTER);
        code.setLetterSpacing(.18f);

        LinearLayout wrap=card(true);
        wrap.setPadding(dp(18),dp(16),dp(18),dp(16));
        TextView title=text("Secure pairing",17,TEXT,true);
        TextView device=text(name==null?"KeyDeck Receiver":name,11,ACCENT,true);
        TextView info=text(host==null?"Enter the current code shown on your PC.":host+"  •  enter the current code shown on your PC.",10,MUTED,false);
        wrap.addView(title,lp(-1,dp(30)));
        wrap.addView(device,lp(-1,dp(24)));
        wrap.addView(info,lp(-1,dp(34),0,5));
        wrap.addView(code,lp(-1,dp(52),2,0));

        AlertDialog d=new AlertDialog.Builder(this)
                .setView(wrap)
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Pair",null)
                .create();
        d.setOnShowListener(x->{
            Window w=d.getWindow();
            if(w!=null) w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            Button positive=d.getButton(AlertDialog.BUTTON_POSITIVE);
            Button negative=d.getButton(AlertDialog.BUTTON_NEGATIVE);
            positive.setTextColor(ACCENT);
            negative.setTextColor(MUTED);
            positive.setOnClickListener(v->{
                String c=code.getText().toString().trim();
                if(c.length()!=6){code.setError("Enter 6 digits");return;}
                d.dismiss();
                conn.pairFreshCurrent(c);
            });
        });
        d.show();
    }

    private void tapKey(int vk){if(vk==0)return;if(!conn.isReady()){toastShort("Connect to the receiver first");return;}conn.key(vk,true);conn.key(vk,false);}
    private void sendCombo(int[] keys){if(!conn.isReady()){toastShort("Connect to the receiver first");return;}if(keys.length==1){tapKey(keys[0]);return;}for(int i=0;i<keys.length-1;i++)conn.key(keys[i],true);int last=keys[keys.length-1];conn.key(last,true);conn.key(last,false);for(int i=keys.length-2;i>=0;i--)conn.key(keys[i],false);}

    private int keyVk(String s){
        Map<String,Integer> m=new HashMap<>();
        m.put("Esc",27);m.put("Tab",9);m.put("Caps",20);m.put("Enter",13);m.put("Bksp",8);m.put("Backspace",8);
        m.put("L Shift",160);m.put("R Shift",161);m.put("L Ctrl",162);m.put("R Ctrl",163);m.put("L Alt",164);m.put("R Alt",165);m.put("L Win",91);m.put("R Win",92);
        m.put("Shift",16);m.put("Ctrl",17);m.put("Alt",18);m.put("Win",91);m.put("Menu",93);m.put("Space",32);
        m.put("Del",46);m.put("Ins",45);m.put("Home",36);m.put("End",35);m.put("PgUp",33);m.put("PgDn",34);m.put("PrtSc",44);m.put("ScrLk",145);m.put("Pause",19);m.put("←",37);m.put("↑",38);m.put("→",39);m.put("↓",40);
        m.put("Num",144);m.put("Num /",111);m.put("Num *",106);m.put("Num -",109);m.put("Num +",107);m.put("Num .",110);m.put("Num Enter",13);
        for(int i=0;i<=9;i++)m.put("Num "+i,96+i);
        m.put("`",192);m.put("-",189);m.put("=",187);m.put("[",219);m.put("]",221);m.put("\\",220);m.put(";",186);m.put("'",222);m.put(",",188);m.put(".",190);m.put("/",191);
        for(int i=1;i<=12;i++)m.put("F"+i,111+i);
        if(m.containsKey(s))return m.get(s);
        if(s.length()==1){char c=Character.toUpperCase(s.charAt(0));if((c>='A'&&c<='Z')||(c>='0'&&c<='9'))return c;}
        return 0;
    }
    private int numpadVk(String s){if("Num".equals(s))return 144;if("/".equals(s))return 111;if("*".equals(s))return 106;if("-".equals(s))return 109;if("+".equals(s))return 107;if(".".equals(s))return 110;if("Enter".equals(s))return 13;if(s.length()==1&&Character.isDigit(s.charAt(0)))return 96+(s.charAt(0)-'0');return 0;}
    private boolean isModifierLabel(String s){return s.contains("Shift")||s.contains("Ctrl")||s.contains("Alt")||s.contains("Win")||"Shift".equals(s)||"Ctrl".equals(s)||"Alt".equals(s)||"Win".equals(s);}
    private boolean isModifierVk(int vk){return vk==16||vk==17||vk==18||vk==91||vk==92||vk==160||vk==161||vk==162||vk==163||vk==164||vk==165;}

    @Override public void onState(String state,String detail){runOnUiThread(()->{statusDot.setTextColor("connecting".equals(state)||"discovering".equals(state)?ACCENT:MUTED);statusText.setText(detail);if("disconnected".equals(state)){statusDot.setTextColor(BAD);releaseStickyModifiers();}});}
    @Override public void onDiscovered(String name,String host,int port){runOnUiThread(()->{
        statusDot.setTextColor(ACCENT); statusText.setText("Receiver found"); pcText.setText(name+" • "+host+":"+port);
        if(pairAfterDiscovery){pairAfterDiscovery=false;showPairCodeDialog(name,host);}
        else if(conn.hasTrustFor(host)) conn.connect();
        else showPairCodeDialog(name,host);
    });}
    @Override public void onPairCodeRequired(){runOnUiThread(()->{statusDot.setTextColor(ACCENT);statusText.setText("Pairing code required");showPairCodeDialog(conn.currentName(),conn.currentHost());});}
    @Override public void onReady(String name,String host){runOnUiThread(()->{statusDot.setTextColor(GOOD);statusText.setText("Connected securely");pcText.setText(name+" • "+host+" • protocol 5");});}
    @Override public void onError(String message){runOnUiThread(()->{statusDot.setTextColor(BAD);statusText.setText("Not connected");toast(message);});}


    private void verifyDeckKeyboardRender() {
        if (!"Deck".equals(currentMode)) return;
        int total=deckKeyboardButtons.size(), visible=0;
        for(Button b:deckKeyboardButtons) if(b.getMeasuredWidth()>0 && b.getMeasuredHeight()>0) visible++;
        if(total==104 && visible==104) return;
        if(!renderRecoveryAttempted){
            renderRecoveryAttempted=true;
            deckKeyboardPercent=Math.max(deckKeyboardPercent,86);
            uiPrefs.edit().putInt("deck_split",deckKeyboardPercent).apply();
            statusText.setText("Recovering keyboard layout…");
            showMode("Deck");
        } else {
            statusDot.setTextColor(BAD);
            statusText.setText("Keyboard layout needs restart");
            toast("Keyboard render check: "+visible+"/"+total+" keys visible. Reopen KeyDeck once.");
        }
    }

    private void updateModeVisuals(){
        for(Map.Entry<String,Button> e:modeButtons.entrySet()) setChipVisual(e.getValue(), e.getKey().equals(currentMode));
    }
    private void setChipVisual(Button b, boolean active){
        b.setTextColor(active?ACCENT:MUTED);
        b.setBackground(active?bg(ACCENT_DARK,10,ACCENT):bg(0x00000000,10,BORDER_SOFT));
    }
    private void setSegmentVisual(Button b, boolean active){
        b.setTextColor(active?TEXT:MUTED);
        b.setBackground(active?bg(ACTIVE,9,ACCENT):bg(SURFACE,9,BORDER_SOFT));
    }
    private StateListDrawable keyBackground(boolean modifier){
        StateListDrawable d=new StateListDrawable();
        d.addState(new int[]{android.R.attr.state_pressed}, bg(KEY_PRESSED,7,ACCENT));
        d.addState(new int[]{}, bg(modifier?KEY2:KEY,7,BORDER_SOFT));
        return d;
    }
    private StateListDrawable buttonBackground(boolean primary){
        StateListDrawable d=new StateListDrawable();
        d.addState(new int[]{android.R.attr.state_pressed}, bg(primary?0xFF8AE2FF:KEY_PRESSED,11,primary?0xFF8AE2FF:ACCENT));
        d.addState(new int[]{}, bg(primary?ACCENT:KEY2,11,primary?ACCENT:BORDER));
        return d;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout card(boolean popup){LinearLayout l=col();l.setBackground(bg(popup?CARD:DECK,popup?18:14,popup?BORDER:BORDER_SOFT));if(popup)l.setElevation(dp(14));return l;}
    private GradientDrawable bg(int color,int radius,int border){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));g.setStroke(dp(1),border);return g;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setIncludeFontPadding(false);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(0xFF62758B);e.setTextColor(TEXT);e.setTextSize(12.5f);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setBackground(bg(0xFF0B1119,10,BORDER));return e;}
    private Button smallButton(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(11.5f);b.setTextColor(primary?0xFF05202B:TEXT);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setIncludeFontPadding(false);b.setPadding(dp(8),0,dp(8),0);b.setMinHeight(0);b.setMinWidth(0);b.setStateListAnimator(null);b.setBackground(buttonBackground(primary));return b;}
    private Button chip(String s){Button b=smallButton(s,false);b.setTextSize(10.5f);b.setTextColor(MUTED);b.setBackground(bg(0x00000000,10,BORDER_SOFT));return b;}
    private Button keyStyleButton(String s,boolean modifier){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(s.length()>8?8.0f:s.length()>5?8.7f:9.6f);b.setTextColor(TEXT);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setIncludeFontPadding(false);b.setGravity(Gravity.CENTER);b.setPadding(dp(1),0,dp(1),0);b.setMinHeight(0);b.setMinWidth(0);b.setStateListAnimator(null);b.setBackground(keyBackground(modifier));return b;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams lp(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(0,dp(top),0,dp(bottom));return p;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void toastShort(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override protected void onDestroy(){releaseStickyModifiers();conn.close();super.onDestroy();}
}
