# KeyDeck Android v1.1.0

Package: `in.tamishra.keydeck`
Version: 1.1.0 (10100)

If an older CI/debug APK refuses to update, uninstall the older KeyDeck APK first, then install v1.1.0. This also clears obsolete Android-side pairing data.
