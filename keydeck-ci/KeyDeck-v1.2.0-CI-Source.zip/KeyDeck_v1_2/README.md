# KeyDeck v1.2.0

KeyDeck turns an Android phone/tablet into a full Windows keyboard, precision touchpad and multi-work controller.

## v1.2.0 full-keyboard + reliability build
- Repairs stale trusted-pairing keys instead of rejecting a new pairing code.
- A 6-digit manual pairing code always starts a clean pairing session.
- QR pairing prefers existing valid trust, then automatically repairs stale trust using the QR pairing code.
- Previous receiver pairing code remains valid briefly after rotation to prevent race-condition rejection.
- Discover always opens the pairing step when a new PC is found.
- Full desktop keyboard restored: F1-F12, Print Screen, Scroll Lock, Pause, Insert, Delete, Home, End, Page Up, Page Down, Menu and full arrows.

## Connection
1. Close every older WirelessKey/KeyDeck receiver.
2. Run KeyDeckReceiver-v1.1.0.exe and allow Private-network firewall access.
3. Keep phone and PC on the same LAN/Wi-Fi.
4. In Android KeyDeck choose Connect > Scan QR.
5. Trusted reconnects are automatic after pairing.

Ports: UDP 8764 discovery, TCP 8765 authenticated input.


## Full 104-key Deck

The main Deck now contains the complete standard 104-key Windows layout on one screen: Esc/F1-F12/system keys, full alphanumeric block, distinct left/right Shift/Ctrl/Alt/Windows keys, Menu, 6-key navigation block, inverted-T arrows, and a 17-key numpad with Num Lock, operators, decimal, tall Plus and Enter.
