package main

import (
	"bufio"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net"
	"path/filepath"
	"testing"
	"time"
)

func testState(t *testing.T) *appState {
	t.Helper()
	s := &appState{
		Trusted:   map[string]trustedDevice{},
		Connected: map[string]string{},
		StorePath: filepath.Join(t.TempDir(), "trusted-devices.json"),
	}
	s.rotateCode()
	return s
}

func startTestListener(t *testing.T, s *appState) (string, func()) {
	t.Helper()
	ln, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan struct{})
	go func() {
		defer close(done)
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go handleTCP(s, c)
		}
	}()
	return ln.Addr().String(), func() { _ = ln.Close(); <-done }
}

func writeLine(t *testing.T, w *bufio.Writer, v any) {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = w.Write(append(b, '\n')); err != nil {
		t.Fatal(err)
	}
	if err = w.Flush(); err != nil {
		t.Fatal(err)
	}
}

func readLine(t *testing.T, r *bufio.Reader) map[string]any {
	t.Helper()
	line, err := r.ReadBytes('\n')
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]any
	if err := json.Unmarshal(line, &m); err != nil {
		t.Fatal(err)
	}
	return m
}

func dialTest(t *testing.T, addr string) (net.Conn, *bufio.Reader, *bufio.Writer) {
	t.Helper()
	c, err := net.DialTimeout("tcp4", addr, 2*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	return c, bufio.NewReader(c), bufio.NewWriter(c)
}

func TestPairingAndTrustedReconnect(t *testing.T) {
	s := testState(t)
	addr, stop := startTestListener(t, s)
	defer stop()

	// Wrong code must be rejected.
	c, r, w := dialTest(t, addr)
	writeLine(t, w, map[string]any{"t": "hello", "proto": protocolVersion, "device": "Test Android", "id": ""})
	if got := readLine(t, r)["t"]; got != "pair_required" {
		t.Fatalf("expected pair_required, got %v", got)
	}
	writeLine(t, w, map[string]any{"t": "pair", "code": "000000"})
	if got := readLine(t, r)["code"]; got != "bad_pair_code" {
		t.Fatalf("expected bad_pair_code, got %v", got)
	}
	_ = c.Close()

	// Correct current code pairs and yields a secret.
	c, r, w = dialTest(t, addr)
	writeLine(t, w, map[string]any{"t": "hello", "proto": protocolVersion, "device": "Test Android", "id": ""})
	if got := readLine(t, r)["t"]; got != "pair_required" {
		t.Fatalf("expected pair_required, got %v", got)
	}
	writeLine(t, w, map[string]any{"t": "pair", "code": s.currentCode()})
	paired := readLine(t, r)
	if paired["t"] != "paired" {
		t.Fatalf("expected paired, got %v", paired)
	}
	id, _ := paired["id"].(string)
	secret, _ := paired["secret"].(string)
	if id == "" || secret == "" {
		t.Fatalf("missing id/secret: %v", paired)
	}
	if got := readLine(t, r)["t"]; got != "ready" {
		t.Fatalf("expected ready, got %v", got)
	}
	writeLine(t, w, map[string]any{"t": "ping"})
	if got := readLine(t, r)["t"]; got != "pong" {
		t.Fatalf("expected pong, got %v", got)
	}
	_ = c.Close()

	// Trusted reconnect must challenge and accept a valid HMAC.
	c, r, w = dialTest(t, addr)
	writeLine(t, w, map[string]any{"t": "hello", "proto": protocolVersion, "device": "Test Android", "id": id})
	challenge := readLine(t, r)
	if challenge["t"] != "challenge" {
		t.Fatalf("expected challenge, got %v", challenge)
	}
	nonce, _ := challenge["nonce"].(string)
	sec, err := base64.RawURLEncoding.DecodeString(secret)
	if err != nil {
		t.Fatal(err)
	}
	mac := hmac.New(sha256.New, sec)
	_, _ = mac.Write([]byte(nonce))
	proof := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
	writeLine(t, w, map[string]any{"t": "auth", "proof": proof})
	if got := readLine(t, r)["t"]; got != "ready" {
		t.Fatalf("expected ready after auth, got %v", got)
	}
	_ = c.Close()
}

func TestPreviousPairCodeGraceWindow(t *testing.T) {
	s := testState(t)
	old := s.currentCode()
	s.rotateCode()
	if !s.validPairCode(old) {
		t.Fatal("previous pairing code should remain valid during grace window")
	}
}

func TestFreshCodeBypassesStaleTrust(t *testing.T) {
	s := testState(t)
	addr, stop := startTestListener(t, s)
	defer stop()

	// Simulate an Android app holding a stale/unknown trust id but also having
	// the current six-digit code from QR/manual entry. The receiver must pair
	// immediately rather than challenge/reject the stale id first.
	c, r, w := dialTest(t, addr)
	writeLine(t, w, map[string]any{
		"t":      "hello",
		"proto":  protocolVersion,
		"device": "Test Android",
		"id":     "stale-device-id",
		"code":   s.currentCode(),
	})
	paired := readLine(t, r)
	if paired["t"] != "paired" {
		t.Fatalf("expected direct paired response, got %v", paired)
	}
	if paired["id"] == "" || paired["secret"] == "" {
		t.Fatalf("missing fresh trust material: %v", paired)
	}
	if got := readLine(t, r)["t"]; got != "ready" {
		t.Fatalf("expected ready after direct pairing, got %v", got)
	}
	_ = c.Close()
}

func TestHotspotLanRangesAccepted(t *testing.T) {
	for _, raw := range []string{"100.64.1.2", "100.127.255.254", "169.254.10.20", "192.168.1.10", "10.0.0.5"} {
		if !isPrivateIP(net.ParseIP(raw)) {
			t.Fatalf("expected LAN address %s to be accepted", raw)
		}
	}
}

func TestDuplicateControlPortIsRejected(t *testing.T) {
	first, err := openControlListener("127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer first.Close()
	addr := first.Addr().String()
	second, err := openControlListener(addr)
	if err == nil {
		second.Close()
		t.Fatal("expected second receiver listener on the same control port to be rejected")
	}
}
