//go:build windows

package main

import (
	"syscall"
	"unicode/utf16"
	"unsafe"
)

var (
	user32     = syscall.NewLazyDLL("user32.dll")
	mouseEvent = user32.NewProc("mouse_event")
	keybdEvent = user32.NewProc("keybd_event")
	sendInput  = user32.NewProc("SendInput")
)

const (
	MOUSEEVENTF_MOVE       = 0x0001
	MOUSEEVENTF_LEFTDOWN   = 0x0002
	MOUSEEVENTF_LEFTUP     = 0x0004
	MOUSEEVENTF_RIGHTDOWN  = 0x0008
	MOUSEEVENTF_RIGHTUP    = 0x0010
	MOUSEEVENTF_MIDDLEDOWN = 0x0020
	MOUSEEVENTF_MIDDLEUP   = 0x0040
	MOUSEEVENTF_WHEEL      = 0x0800
	KEYEVENTF_EXTENDEDKEY  = 0x0001
	KEYEVENTF_KEYUP        = 0x0002
	KEYEVENTF_UNICODE      = 0x0004
	INPUT_KEYBOARD         = 1
)

func injectMove(dx, dy int) {
	mouseEvent.Call(MOUSEEVENTF_MOVE, uintptr(uint32(int32(dx))), uintptr(uint32(int32(dy))), 0, 0)
}
func injectMouseButton(button string, down bool) {
	var flag uintptr
	switch button {
	case "right":
		if down {
			flag = MOUSEEVENTF_RIGHTDOWN
		} else {
			flag = MOUSEEVENTF_RIGHTUP
		}
	case "middle":
		if down {
			flag = MOUSEEVENTF_MIDDLEDOWN
		} else {
			flag = MOUSEEVENTF_MIDDLEUP
		}
	default:
		if down {
			flag = MOUSEEVENTF_LEFTDOWN
		} else {
			flag = MOUSEEVENTF_LEFTUP
		}
	}
	mouseEvent.Call(flag, 0, 0, 0, 0)
}
func injectClick(button string) {
	var down, up uintptr
	switch button {
	case "right":
		down, up = MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP
	case "middle":
		down, up = MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP
	default:
		down, up = MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP
	}
	mouseEvent.Call(down, 0, 0, 0, 0)
	mouseEvent.Call(up, 0, 0, 0, 0)
}
func injectScroll(dy int) { mouseEvent.Call(MOUSEEVENTF_WHEEL, 0, 0, uintptr(uint32(int32(dy))), 0) }
func injectKey(vk int, down bool) {
	var flags uintptr
	if isExtendedVK(vk) {
		flags |= KEYEVENTF_EXTENDEDKEY
	}
	if !down {
		flags |= KEYEVENTF_KEYUP
	}
	keybdEvent.Call(uintptr(byte(vk)), 0, flags, 0)
}

func isExtendedVK(vk int) bool {
	switch vk {
	case 33, 34, 35, 36, 37, 38, 39, 40, // Page/Home/End/arrows
		45, 46, // Insert/Delete
		91, 92, 93, // Windows/Menu
		111,      // numpad divide
		163, 165: // right Ctrl / right Alt
		return true
	default:
		return false
	}
}

type keyboardInput struct {
	WVk         uint16
	WScan       uint16
	DwFlags     uint32
	Time        uint32
	DwExtraInfo uintptr
}
type input struct {
	Type uint32
	_    uint32
	Ki   keyboardInput
	_    [8]byte
}

func sendUnicodeUnit(u uint16, up bool) {
	flags := uint32(KEYEVENTF_UNICODE)
	if up {
		flags |= KEYEVENTF_KEYUP
	}
	in := input{Type: INPUT_KEYBOARD, Ki: keyboardInput{WScan: u, DwFlags: flags}}
	sendInput.Call(1, uintptr(unsafe.Pointer(&in)), unsafe.Sizeof(in))
}
func injectText(s string) {
	for _, u := range utf16.Encode([]rune(s)) {
		sendUnicodeUnit(u, false)
		sendUnicodeUnit(u, true)
	}
}
