from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / 'android/app/src/main/java/in/tamishra/keydeck/MainActivity.java'
s = SRC.read_text(encoding='utf-8')

function = ['Esc'] + [f'F{i}' for i in range(1, 13)] + ['PrtSc', 'ScrLk', 'Pause']
main = (
    ['`'] + list('1234567890') + ['-', '=', 'Backspace'] +
    ['Tab'] + list('QWERTYUIOP') + ['[', ']', '\\'] +
    ['Caps'] + list('ASDFGHJKL') + [';', "'", 'Enter'] +
    ['L Shift'] + list('ZXCVBNM') + [',', '.', '/', 'R Shift'] +
    ['L Ctrl', 'L Win', 'L Alt', 'Space', 'R Alt', 'R Win', 'Menu', 'R Ctrl']
)
nav = ['Ins', 'Home', 'PgUp', 'Del', 'End', 'PgDn', '←', '↑', '↓', '→']
num = ['Num', 'Num /', 'Num *', 'Num -', 'Num 7', 'Num 8', 'Num 9', 'Num +',
       'Num 4', 'Num 5', 'Num 6', 'Num 1', 'Num 2', 'Num 3', 'Num 0', 'Num .', 'Num Enter']
keys = function + main + nav + num

assert len(function) == 16
assert len(main) == 61
assert len(nav) == 10
assert len(num) == 17
assert len(keys) == 104

for key in keys:
    encoded = '"' + key.replace('\\', '\\\\') + '"'
    assert encoded in s, f'missing UI key: {key}'

required = {
    'Esc':27, 'PrtSc':44, 'ScrLk':145, 'Pause':19, 'Backspace':8, 'Tab':9,
    'Caps':20, 'Enter':13, 'L Shift':160, 'R Shift':161, 'L Ctrl':162,
    'R Ctrl':163, 'L Alt':164, 'R Alt':165, 'L Win':91, 'R Win':92,
    'Menu':93, 'Space':32, 'Ins':45, 'Home':36, 'PgUp':33, 'Del':46,
    'End':35, 'PgDn':34, '←':37, '↑':38, '↓':40, '→':39,
    'Num':144, 'Num /':111, 'Num *':106, 'Num -':109, 'Num +':107,
    'Num .':110, 'Num Enter':13,
    '`':192, '-':189, '=':187, '[':219, ']':221, '\\':220, ';':186,
    "'":222, ',':188, '.':190, '/':191,
}
for key, vk in required.items():
    esc = key.replace('\\', '\\\\').replace('"', '\\"')
    assert f'm.put("{esc}",{vk})' in s, f'missing VK mapping: {key} -> {vk}'

assert 'for(int i=0;i<=9;i++)m.put("Num "+i,96+i);' in s
assert 'for(int i=1;i<=12;i++)m.put("F"+i,111+i);' in s
assert 'vk==160||vk==161||vk==162||vk==163||vk==164||vk==165' in s
print('FULL_KEYBOARD_QC=PASS total=104 function=16 main=61 nav=10 numpad=17')

# Layout regression: ordinary keyboard keys must occupy the weighted row height.
assert 'new LinearLayout.LayoutParams(0,-1,weights[i])' in s, 'key height regression: keys would collapse'
assert 'p.height = 0;' not in s, 'key height regression: explicit zero height found'
assert 'new LinearLayout.LayoutParams(0,-1,1f);' in s, 'arrow-cluster keys must fill row height'
print('KEY_RENDER_QC=PASS nonzero_key_height=true')
